Change history
==============

0.4.1 (2013-08-27)
------------------

 * Remove direct dependency on ``pcl`` (`ros/rosdistro#1676`_).
 * ROS Hydro.

0.4.0 (2013-07-24)
------------------

 * ROS Hydro.
 * Convert to catkin build system.
 * Remove from ``velodyne_utils`` stack.

0.3.0 (2012-04-03)
------------------

 * Rosbuild version, included in ``velodyne_utils`` stack, which was
   supported for the ROS Electric, Fuerte and Groovy distributions.

.. _`ros/rosdistro#1676`: https://github.com/ros/rosdistro/issues/1676
