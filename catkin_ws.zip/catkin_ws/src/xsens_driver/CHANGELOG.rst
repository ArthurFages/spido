^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package xsens_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.3 (2014-05-14)
------------------
* Inclusion of launch file
* Additions and fixes from PAL robotics
* Add local frame conversion for calibrated imu data (acc, gyr, mag)
* Contributors: Enrique Fernandez, Francis Colas, Paul Mathieu, Sam Pfeiffer

1.0.2 (2014-03-04)
------------------
* catkinized
* experimental support of mark 4 IMUs
* fixed scaling in DOP values
* adding publisher for full data as a string
* relative topic names

1.0.1 (2012-08-27)
------------------
* minor improvements
* naming cleanup
* Contributors: Benjamin Hitov, Francis Colas, Nikolaus Demmel, Stéphane Magnenat, fcolas
