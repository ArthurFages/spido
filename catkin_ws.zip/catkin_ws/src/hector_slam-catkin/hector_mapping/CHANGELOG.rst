^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2014-03-30)
------------------

0.3.1 (2013-10-09)
------------------
* respect ``p_map_frame_``
* added changelogs

0.3.0 (2013-08-08)
------------------
* catkinized hector_slam
* hector_mapping: fixed multi-resolution map scan matching index bug in MapRepMultiMap.h
