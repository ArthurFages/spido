/*
 * Copyright (c) 2010, Willow Garage, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Willow Garage, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


/*
 *This driver is adapted from turtlebot_teleop package, it is a quick adaptation
 *that allows a simple teleoperation of the spido (Robosoft Fast-b) robot.
 */
 
#include <ros/ros.h>
//#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include "spido_pure_interface/cmd_car.h" 
#include "boost/thread/mutex.hpp"
#include "boost/thread/thread.hpp"
#include "ros/console.h"

class SpidoTeleop
{
public:
  SpidoTeleop();

private:
  void joyCallback(const sensor_msgs::Joy::ConstPtr& joy);
  void publish();

  ros::NodeHandle ph_, nh_;

  int linear_, angular_, deadman_axis_;
  double linear_scale_, steering_scale_;
  ros::Publisher vel_pub_;
  ros::Subscriber joy_sub_;

  spido_pure_interface::cmd_car last_published_;
  boost::mutex publish_mutex_;
  bool deadman_pressed_;
  ros::Timer timer_;
  
  //bool timeout_flag = false;
  //bool old_timeout_flag = true;

};

SpidoTeleop::SpidoTeleop():
  ph_("~"),
  linear_(1),
  angular_(0),
  deadman_axis_(0),
  linear_scale_(10),
  steering_scale_(0.3)
{
  ph_.param("axis_linear", linear_, linear_);
  ph_.param("axis_angular", angular_, angular_);
  ph_.param("axis_deadman", deadman_axis_, deadman_axis_);
  ph_.param("scale_angular", steering_scale_, steering_scale_);
  ph_.param("scale_linear", linear_scale_, linear_scale_);

  //Solve bug documented in https://github.com/turtlebot/turtlebot_apps/issues/71
  deadman_pressed_ = false;

  //vel_pub_ = ph_.advertise<geometry_msgs::Twist>("cmd_vel", 1);
  vel_pub_ = nh_.advertise<spido_pure_interface::cmd_car>("cmd_car", 1);
  joy_sub_ = nh_.subscribe<sensor_msgs::Joy>("joy", 10, &SpidoTeleop::joyCallback, this);

  timer_ = nh_.createTimer(ros::Duration(0.1), boost::bind(&SpidoTeleop::publish, this));
}

void SpidoTeleop::joyCallback(const sensor_msgs::Joy::ConstPtr& joy)
{ 
  //geometry_msgs::Twist vel;
  spido_pure_interface::cmd_car cmd_car;
  //vel.angular.z = a_scale_*joy->axes[angular_];
  cmd_car.steering_angle_front = steering_scale_*joy->axes[angular_];
  //vel.linear.x = l_scale_*joy->axes[linear_];
  cmd_car.linear_speed = linear_scale_*joy->axes[linear_];
  last_published_ = cmd_car;
  //ROS_INFO("deadman_pressed: %i",joy->buttons[deadman_axis_]);
  deadman_pressed_ = joy->buttons[deadman_axis_];
}

void SpidoTeleop::publish()
{
  boost::mutex::scoped_lock lock(publish_mutex_);
  //ROS_INFO("deadman_test");
  if (deadman_pressed_)
  {
    vel_pub_.publish(last_published_);
    //ROS_INFO("deadman_ok");
  }
/*  else if(last_published_.linear_speed == 0 && !deadman_pressed_) 
  {
      
  }*/
  else                              //set linear speed to 0 if there is the last
  {                                 //command was <> 0 and deadman released
    //geometry_msgs::Twist vel;
    spido_pure_interface::cmd_car cmd_car;
    //vel.angular.z = a_scale_*joy->axes[angular_];
    cmd_car.steering_angle_front = 0;
    //vel.linear.x = l_scale_*joy->axes[linear_];
    cmd_car.linear_speed = 0;
    vel_pub_.publish(cmd_car);
    ROS_INFO("cmd timeout with linear speed <> 0, set speed to 0");
  }
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "spido_teleop");
  SpidoTeleop turtlebot_teleop;

  ros::spin();
}
