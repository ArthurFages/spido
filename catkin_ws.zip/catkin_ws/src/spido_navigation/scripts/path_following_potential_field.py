#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import copy
from std_msgs.msg import String, Float32, Int32
from sensor_msgs.msg import LaserScan
from math import cos, sin, sqrt, atan2, hypot, pi
from matplotlib import pyplot
import tf
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import PointStamped, Point
from visualization_msgs.msg import Marker
from nav_msgs.msg import Odometry
import numpy
from filtrage import filtrage
import matplotlib.patches as patches
                                                                 #initialisation
goalx = 0.0
goaly = 0.0
transformed_goalx = 10.0
transformed_goaly = 10.0
goal_force_x = 0.0
goal_force_y = 0.0
near_range = 30
far_range = 50
flag = 0
obs_x = []
obs_y = []
obstacles_forcex = 0.0
obstacles_forcey = 0.0
forcex = 0.0
forcey = 0.0
forcex_display = 0.0
forcey_display = 0.0
old_range = 0.0
obstacle_min_dist = -1.0
obstacle_min_angle = 0.
target_curve = 2
obstacle_distance = 0.
psi = 0.
posX = 0.
posY = 0.
earth_radius = 6370.0e3 # earth radius in meters

# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
#                               main options                                   #
################################################################################
#display = True
display = False

goal_force_factor = 15
obstacle_force_factor = 15 #unused for now...
            #difference of range between two consecutive rays to take in account
downsample_distance = 1.5 
compass_driver = False
#compass_driver = True
force_type = 1
################################################################################
def compute_obstacle_force(distance,angle):
    ''' returns the 'force_factor' for a given distance to the obstacle.
    the force calculated will have force_factor as a norm and the oposite
    direction to the obstacle (repulsive obstacles). '''
    global obstacle_force_factor
    global force_type
    if force_type == 1:                    #working with spido gazebo simulation
        if distance > 2:
            force_factor = - 6.25/pow((distance),2) * obstacle_force_factor
        else :
            force_factor = - 6.25/pow((distance),2) * obstacle_force_factor
    elif force_type == 2:                                      #used for pioneer
        if distance > 2.5:
            force_factor = 0
        else :
            force_factor = - 1/pow((distance + 0.8),4) * obstacle_force_factor
    elif force_type == 3:
        if distance < c_obstacle_max_influence:
            force_factor = - 1/pow((distance + b_x_shift),
                                  a_obstacle_pow_factor) * obstacle_force_factor
            if use_angle_force_reducer == True:
                force_factor = force_factor * (3.15 -
                                               angle_force_reducer * abs(angle))
        else:
            force_factor = 0
    elif force_type == 4:
        if distance > 2:
            force_factor = - 1/pow((distance),2) * obstacle_force_factor
        else :
            force_factor = - 1/pow((distance),2) * obstacle_force_factor
    return force_factor
################################################################################
def lasercallback(data):
    global flag
    global farx
    global fary
    global obstacles_forcex
    global obstacles_forcey
    global forcex
    global forcey
    global goal_force_x
    global goal_force_y
    global old_range
    global obstacle_min_dist
    global obstacle_min_angle
    global near_range
    global far_range
    global obstacle_distance
    angle_index=0.0;
    farx = []
    fary = []
    xi = 0.0
    yi = 0.0
    j = 0
    forcex = 0.0
    forcey = 0.0
    min_dist = -1.0
    n = 0                                        #remind the last point recorded
#avoid plotting half laserscan data causing dimension problems
#TODO: buffer all the variables to be plotted ...
    flag = 0 
    for i in range(0,len(data.ranges)):
        angle_index = data.angle_increment*i
        foce_factor = 0.0
        if min_dist < 0 or min_dist > data.ranges[i]:
            min_dist = data.ranges[i]
            min_ang = angle_index
                                            #distance to the last point recorded
        d = sqrt(pow(data.ranges[i],2)+pow(data.ranges[n],2)-
                2*data.ranges[i]*data.ranges[n]*cos((i-n)*data.angle_increment))
        if d > downsample_distance:
            n = i
            if data.ranges[i] < near_range:
                xi = -data.ranges[i]*cos(angle_index)
                yi = -data.ranges[i]*sin(angle_index)
                #compute the force induced by the obstacle
                force_factor = compute_obstacle_force(data.ranges[i],angle_index)
                obstacle_distance = data.ranges[i]
                forcex = forcex + force_factor*xi
                forcey = forcey + force_factor*yi
                j = j + 1
                obs_x.append(posX + xi*cos(psi)-yi*sin(psi))
                obs_y.append(posY + xi*sin(psi)+yi*cos(psi))
                
            elif data.ranges[i] < far_range:
                xj = -data.ranges[i]*cos(angle_index)
                yj = -data.ranges[i]*sin(angle_index)
                farx.append(-data.ranges[i]*cos(angle_index))
                fary.append(-data.ranges[i]*sin(angle_index))
                j = j + 1
                obs_x.append(posX + xj*cos(psi)-yj*sin(psi))
                obs_y.append(posY + xj*sin(psi)+yj*cos(psi))
            old_range = data.ranges[i]
    obstacle_min_dist = min_dist
    obstacle_min_angle = min_ang
    flag = 1
    #compute force induced by goal point----------------------------------------
    goal_distance = sqrt(pow(transformed_goalx,2)+pow(transformed_goaly,2))
    if goal_distance > 1:
        goal_force_x = goal_force_factor * transformed_goalx/goal_distance
        goal_force_y = goal_force_factor * transformed_goaly/goal_distance
    else:
        goal_force_x = goal_force_factor * transformed_goalx
        goal_force_y = goal_force_factor * transformed_goaly
               #TODO: do something to stop when getting close enouth to the goal
        rospy.loginfo("getting close to the goal :) ")
################################################################################
def markerspublish(pubgoalmarker, pubobstaclemarker, pubforcemarker):
    origin = Point()
    goalend = Point()
    obstacleend = Point()
    forceend = Point()
    goalend.x = goal_force_x
    goalend.y = goal_force_y
    obstacleend.x = forcex
    obstacleend.y = forcey
    forceend.x = goal_force_x + forcex
    forceend.y = goal_force_y + forcey
    rospy.loginfo("fx: %f, fy: %f, gfx: %f, gfy: %f", forcex, forcey, goal_force_x, goal_force_y)
    rospy.loginfo("forceend.x: %f, forceend.y: %f", forceend.x, forceend.y)
    goalmarker = Marker()
    goalmarker.type = 0
    goalmarker.ns = "potential_field"
    goalmarker.header.stamp = rospy.Time.now()
    goalmarker.header.frame_id = "velodyne"
    goalmarker.lifetime.secs = 0.2
    goalmarker.color.a = 1.0
    goalmarker.scale.x = 0.1
    goalmarker.scale.y = 0.3
    goalmarker.scale.z = 0.3
    goalmarker.points.append(origin)
    
    obstaclemarker = Marker()
    forcemarker = Marker()
    obstaclemarker = copy.deepcopy(goalmarker)           #copying global setup to other markers
    forcemarker = copy.deepcopy(goalmarker) 

    goalmarker.points.append(goalend)
    goalmarker.color.g = 1.0
    
    obstaclemarker.points.append(obstacleend)
    obstaclemarker.color.r = 1.0
    
    forcemarker.points.append(forceend)
    forcemarker.color.b = 1.0
    
    pubgoalmarker.publish(goalmarker)
    pubobstaclemarker.publish(obstaclemarker)
    pubforcemarker.publish(forcemarker)
    rospy.loginfo("publishing markers")
################################################################################
def odomCallback(data):
    global posX
    global posY
    global psi    
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
    quaternion = (
    data.pose.pose.orientation.x,
    data.pose.pose.orientation.y,
    data.pose.pose.orientation.z,
    data.pose.pose.orientation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    psi = euler[2]
################################################################################
def goalCallback(data):
    global goalx
    global goaly
    goalx = data.x
    goaly = data.y
################################################################################
def potentialfield():
    global flag
    global forcex_display
    global forcey_display
    global goalx
    global goaly
    global transformed_goalx
    global transformed_goaly
    global compass_driver
    global obstacle_min_dist
    
    obstacle = Point()
    obstacle.x = 0.
    obstacle.y = 0.
    
    rospy.init_node('potential_field')
    
    laserscan_topic='/spido/laser/scan'
    if rospy.has_param('potential_field/laserscan_topic'):
        laserscan_topic = rospy.get_param('potential_field/laserscan_topic')
    rospy.loginfo("using laserscan topic : %s", laserscan_topic)
    rospy.Subscriber(laserscan_topic, LaserScan, lasercallback)
    tflistener = tf.TransformListener()
    
    pubbearing = rospy.Publisher('potential_field/bearing',Float32,queue_size=10)
    pubnormobs = rospy.Publisher('potential_field/norm_obs',Float32,queue_size=10)
    pub_obs_dist = rospy.Publisher('/obstacle/dist',Float32,queue_size=10)
    pub_obs_coord = rospy.Publisher('/obstacle/coord',Point,queue_size=10)
    
    # marker for rviz
    pubgoalmarker = rospy.Publisher('potential_field/goal_maker', Marker)
    pubobstaclemarker = rospy.Publisher('potential_field/obstacles_maker',Marker)
    pubforcemarker = rospy.Publisher('potential_field/force_maker', Marker)
    
    # subscribe to the odometry
    rospy.Subscriber("odom", Odometry, odomCallback)
    # subscribe to the target point
    rospy.Subscriber('target_publisher', Point, goalCallback)
    
    r = rospy.Rate(100)
    while not rospy.is_shutdown():
        xi = -obstacle_min_dist*cos(obstacle_min_angle)
        yi = -obstacle_min_dist*sin(obstacle_min_angle)        
        obstacle.x = posX+xi*cos(psi)-yi*sin(psi)
        obstacle.y = posY+xi*sin(psi)+yi*cos(psi)
        pub_obs_dist.publish(obstacle_min_dist)
        pub_obs_coord.publish(obstacle)
        #get the goal position and transform it into hokuyo_link frame
        if compass_driver == False:
            try:
                now = rospy.Time.now()
                   #wait for the next available transform between the two frames
                tflistener.waitForTransform('world', 'hokuyo_link', now,
                                                            rospy.Duration(4.0))
                p = PointStamped()
                p.header.stamp = rospy.Time()
                p.header.frame_id = "world"
                p.point.x = goalx
                p.point.y = goaly
                p.point.z = 0
                p = tflistener.transformPoint('hokuyo_link',p)
                transformed_goalx = p.point.x
                transformed_goaly = p.point.y
            except (tf.LookupException, tf.ConnectivityException,tf.Exception):
                             #show error if the tf transform couldnt be obtained
                rospy.loginfo("tf Exception!, shouldn't happend at hight frequency")
                #continue
        else:
                rospy.loginfo("working with compass driver")
        
        #compute bearing angle, norm of the computed force and distance to goal
        bearing = atan2(forcey,forcex)
        normobs = hypot(forcex, forcey)
        #publih bearing norm and distance
        pubbearing.publish(bearing)
        pubnormobs.publish(normobs)
        
        #publish markers
        markerspublish(pubgoalmarker, pubobstaclemarker, pubforcemarker)
        
        r.sleep()
    
if __name__ == '__main__':
    try:
        potentialfield()
    except rospy.ROSInterruptException: pass
