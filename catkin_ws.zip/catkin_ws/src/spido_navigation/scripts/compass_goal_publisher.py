#!/usr/bin/env python2
import rospy
from math import cos, sin, atan2
from std_msgs.msg import Float32
from geometry_msgs.msg import PointStamped, Vector3Stamped
goal_transformedx = 0.0
goal_transformedy = 0.0

bearing_target = 0.0
goal_distance = 10
magnetic_bearing = 0.0

################################################################################
def bearingcallback(data):
    global bearing_target
    bearing_target = data.data
################################################################################
def measurecallback(data):
    global magnetic_bearing
    global goal_transformedx
    global goal_transformedy
    global bearing_target
    global goal_distance
    magnetic_bearig = atan2(data.vector.y,data.vector.x)
    angle_to_target = bearing_target + magnetic_bearig
    goal_transformedx = goal_distance * cos(angle_to_target)
    goal_transformedy = goal_distance * sin(angle_to_target)    
  
################################################################################
def compassdriver():
    ''' This nodes subscribes to a Xsens "/magnetic" topic and computes a goal
    in the robot frame. This will allow autonomous navigation with magnetic
    bearing following capabilities. '''
    global goal_transformedx
    global goal_transformedy
    rospy.init_node('compass_goal_publisher')
    rospy.Subscriber("magnetic_target_bearing", Float32, bearingcallback)
    rospy.Subscriber("magnetic", Vector3Stamped, measurecallback)

    transformed_goal_publisher = rospy.Publisher(
                                  'goal_transformed',PointStamped,queue_size=10)
    r = rospy.Rate(10)                                         #loop rate = 10Hz
    while not rospy.is_shutdown():
        p = PointStamped()
        p.header.stamp = rospy.Time()
        p.header.frame_id = "velodyne"
        p.point.x = goal_transformedx
        p.point.y = goal_transformedy
        p.point.z = 0
        transformed_goal_publisher.publish(p)
        r.sleep()
if __name__ == '__main__':
    compassdriver()
