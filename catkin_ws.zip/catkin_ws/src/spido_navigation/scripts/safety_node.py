#!/usr/bin/env python2
import rospy
from math import copysign
from spido_pure_interface.msg import cmd_car
from std_msgs.msg import Float32, Bool
from dynamic_reconfigure.server import Server
from spido_navigation.cfg import SafetyConfig

#max_speed
#speed_factor
#obstacle_min_dist

new_cmd = False
deadman_pressed = False
safe_cmd = cmd_car()
obstacle_min_dist = 0.0

def reconfigurecallback(config, level):
    global max_speed
    global speed_factor
    global min_dist
    global allow_reverse
    allow_reverse = config.allow_reverse
    max_speed = config.max_speed
    speed_factor = config.speed_factor
    min_dist = config.obstacle_min_dist
    return config

def cmdcallback(data):
    global safe_cmd
    global new_cmd
    linear_speed = data.linear_speed
    linear_speed = speed_factor * linear_speed
    if allow_reverse == False and linear_speed < 0:
        linear_speed = 0
    if abs(linear_speed) > max_speed:
        linear_speed = copysign(1,linear_speed) * max_speed
    safe_cmd = cmd_car()
    safe_cmd.linear_speed = linear_speed
    safe_cmd.steering_angle = data.steering_angle
    new_cmd = True
    
def speedcallback(data):
    global speed_factor
    speed_factor = data.data
    
def deadmancallback(data):
    global deadman_pressed
    if data.data == True:
        deadman_pressed = True
    else:
        deadman_pressed = False
        
def mindistcallback(data):
    global obstacle_min_dist
    obstacle_min_dist = data.data
    
    

def safetynode():
    global new_cmd
    global safe_cmd
    rospy.init_node('safety_node')
    srv = Server(SafetyConfig, reconfigurecallback)
    rospy.Subscriber("cmd_car", cmd_car, cmdcallback)
    rospy.Subscriber("supervisor/speed_factor", Float32, speedcallback)
    rospy.Subscriber("supervisor/deadman", Bool, deadmancallback)
    rospy.Subscriber("obstacle_min_dist", Float32, mindistcallback)
    cmd_publisher = rospy.Publisher('cmd_car_safe',cmd_car,queue_size=10)
    r = rospy.Rate(50) # 50hz
    while not rospy.is_shutdown():
        if deadman_pressed == True and obstacle_min_dist > min_dist:
            cmd_publisher.publish(safe_cmd)
            new_cmd = False
        else:
            safe_cmd.linear_speed = 0.0
            rospy.loginfo("deadman released! :O")
            cmd_publisher.publish(safe_cmd)
            new_cmd = False
        r.sleep()
        
if __name__ == '__main__':
    safetynode()
