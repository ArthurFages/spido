#!/usr/bin/env python2
# -*- coding: utf-8 -*-

################################################################################
# Motion Control of Wheeled Mobile Robots
#                       P. Morin and C. Samson
#                34.3.1 Stabilization of Trajectories for a Nonconstrained Point
################################################################################
import rospy
from nav_msgs.msg import Odometry
from visualization_msgs.msg import Marker
from spido_pure_interface.msg import cmd_car
from std_msgs.msg import String, Float32, Int32
from geometry_msgs.msg import PointStamped, Point
import tf

from matplotlib import pyplot
import numpy
from math import fabs, tan, cos, sin, hypot, pi, atan, atan2, copysign, asin
import time

from filtrage import filtrage
import sys
################################################################################
length = 2.2
axles_dist = 1.5 # distance between axles
wheel_radius = .3

target_curve = 3 # if dist<target_curve, the vehicle is close to the curve

# Position
posX = 0.0
posY = 0.0
psi = 0.0
latitude = 0.0
longitude = 0.0

earth_radius = 6370.0e3 # earth radius in meters

# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
def fileOpenning(file_name):
    fileX = numpy.array([])
    fileY = numpy.array([])
    fileT = numpy.array([])
    cpt = -1
    seuil = 0.1
    
    Fichier = open(file_name, 'r')
    
    for ligne in Fichier:
        donnees = ligne.rstrip('\n\r').split(";")
        if cpt == -1:
            for i in range(len(donnees)):
                if donnees[i] == 'Latitude':
                    idx_lat = i
                elif donnees[i] == 'Longitude':
                    idx_long = i
                elif donnees[i] == 'T':
                    idx_t = i
            cpt += 1
        elif(hypot(float(donnees[idx_lat]), float(donnees[idx_long])) != 0):
            latitude = float(donnees[idx_lat])*pi/180
            longitude = float(donnees[idx_long])*pi/180
            x = earth_radius*longitude*cos(latitude) - x_origine
            y = earth_radius*latitude - y_origine
            if cpt == 0 :
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            elif( hypot(x-fileX[cpt-1], y-fileY[cpt-1]) != 0 and
                                     hypot(x-fileX[cpt-1], y-fileY[cpt-1]) < 1):
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            
    Fichier.close()
    """
    traj = filtrage(fileX, fileY, fileT)
    trajX = traj[0]
    trajY = traj[1]
    trajX = trajX-trajX[0]+4
    trajY = trajY-trajY[0]+5
    trajT = traj[2]
    """
    trajX = fileX-fileX[0]+4
    trajY = fileY-fileY[0]-2
    trajT = fileT
    speedX = numpy.zeros(trajX.size)
    speedY = numpy.zeros(trajY.size)
    for i in range(1, trajX.size-1):
        speedX[i] = (trajX[i]-trajX[i-1])/(trajT[i]-trajT[i-1])
        speedY[i] = (trajY[i]-trajY[i-1])/(trajT[i]-trajT[i-1])
        
    return trajX, trajY,speedX, speedY, trajT
################################################################################
def inverse_commande(v1, v2, phi):
    a = cos(psi)-sin(psi)*tan(phi)-wheel_radius/axles_dist*tan(phi)*sin(phi+psi)
    b = -wheel_radius*sin(psi+phi)
    c = sin(psi)+cos(psi)*tan(phi)+wheel_radius/axles_dist*tan(phi)*cos(phi+psi)
    d = wheel_radius*cos(psi+phi)
    delta = a*d-b*c
    u1 = (d*v1-b*v2)/delta
    u2 = (-c*v1+a*v2)/delta
    return u1, u2
################################################################################
def odomCallback(data):
    global posX
    global posY
    global psi    
    quaternion = (
    data.pose.pose.orientation.x,
    data.pose.pose.orientation.y,
    data.pose.pose.orientation.z,
    data.pose.pose.orientation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    psi = euler[2]
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
################################################################################
def pathReproducerDriver(argv, argv3, argv4, argv5):
    Speed = float(argv3)
    k1 = float(argv4)
    k2 = float(argv5)
    Target = Point()
    # Command
    u1 = 0.0
    u2 = 0.0
    GOAL = False
    close = False
    dT = 0.
    T0 = 0.
    T1 = 0.
    T2 = 0.
    Path = fileOpenning(argv)
    trajX = Path[0]
    trajY = Path[1]
    speedX = Path[2]
    speedY = Path[3]
    trajT = Path[4]
    flag_begin=0
    
    errorDist = numpy.array([])
    
    rospy.init_node('path_follower_driver')
    
    rospy.Subscriber("odom", Odometry, odomCallback)
    
    cmd_publisher = rospy.Publisher('cmd_car',cmd_car,queue_size=10)
    target_publisher = rospy.Publisher('target_publisher', Point, queue_size=10)
    path_publisher = rospy.Publisher('path_to_follow',Marker)
    state_pub = rospy.Publisher('state', Int32, queue_size=10)
    
    r = rospy.Rate(100) # 100hz
    
    while not rospy.is_shutdown():
        cmd = cmd_car()
        cmd.linear_speed = u1
        cmd.steering_angle = u2
        # memorize the first position
        if flag_begin==0:
            beginx = posX
            beginy = posY
            flag_begin = 1
        if GOAL == False:
            if (hypot(posX - trajX[0], posY - trajY[0]) < target_curve):
                close = True
            else:
                while (close == False): # Go close to the curve
                    u2 = atan2((trajY[0]-posY)*cos(psi)-(trajX[0]-posX)*sin(psi),
                              (trajY[0]-posY)*sin(psi)+(trajX[0]-posX)*cos(psi))
                    if fabs(u2) > 0.3:
                        u2 = copysign(0.3, u2)
                    cmd.linear_speed = Speed
                    cmd.steering_angle = u2
                    cmd_publisher.publish(cmd)
                    target_publisher.publish(Target)
                    state_pub.publish(0)
                    if (hypot(posX - trajX[0], posY - trajY[0]) < target_curve):
                        close = True
            
            # The robot is close enought of the trajectory to reproduce it
            cpt = 0
            now = rospy.get_rostime()
            T0 = now.secs+now.nsecs*1.0e-9
            #T0 = time.time()
            while (cpt < trajT.size):
                targetX = trajX[cpt]
                targetY = trajY[cpt]
                Target.x = targetX
                Target.y = targetY
                # linear_speed and steering_angle computation
                now = rospy.get_rostime()
                T1 = T2
                T2 = now.secs+now.nsecs*1.0e-9
                #T2 = time.time()
                dT = T2 - T1
                v1 = speedX[cpt] - k1*(posX - trajX[cpt])
                v2 = speedY[cpt] - k2*(posY - trajY[cpt])
                commande = inverse_commande(v1, v2, u2)
                u1 = commande[0]
                u2 += (commande[1] * dT)
                if u1 < 0:
                    u1 = 0
                if u1 > Speed:
                    u1 = Speed
                if fabs(u2) > 0.3:
                    u2 = copysign(0.3, u2)
                cmd.linear_speed = u1
                cmd.steering_angle = u2
                
                # publication
                cmd_publisher.publish(cmd)
                target_publisher.publish(Target)
                state_pub.publish(0)
                
                Time = T2-T0 + trajT[0]
                
                for i in range(cpt, trajT.size-2):
                    if Time>=trajT[i] and Time<trajT[i+1]:
                        cpt = i
                if Time > trajT[trajT.size-1]:
                    cpt = trajT.size
            
            GOAL = True
        
        else: # GOAL = True
            # Mission accomplished => stop
            cmd.steering_angle = 0
            cmd.linear_speed = 0
            cmd_publisher.publish(cmd)
            Target.x = beginx
            Target.y = beginy
            target_publisher.publish(Target)
            state_pub.publish(1)

        r.sleep()
################################################################################  
if __name__ == '__main__':
    if len(sys.argv) != 5:
        print "Wrong number of arguments : expecting name file, a speed and gains"
    else:
        pathReproducerDriver(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
