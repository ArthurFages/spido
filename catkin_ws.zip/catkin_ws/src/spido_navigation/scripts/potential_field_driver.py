#!/usr/bin/env python2
import rospy
from std_msgs.msg import Float32
from spido_pure_interface.msg import cmd_car

from dynamic_reconfigure.server import Server
from spido_navigation.cfg import DriverConfig

from math import fabs, copysign

bearing = 0.0
norm = 0.0
kpb = 0.4 #replaced by dynamic reconfigure
kpn = 1 #replaced by dynamic reconfigure
max_speed = 5 #replaced by dynamic reconfigure
target_reached = False
target_radius = 2                               #zone definig the target_reached

def reconfigurecallback(config, level):
    global max_speed
    global kpb
    global kpn
    global target_radius
    max_speed = config.max_speed
    kpb = config.kpb
    kpn = config.kpn
    target_radius = config.target_radius
    return config

def bearingcallback(data):
    global bearing
    bearing = data.data
    #rospy.loginfo(rospy.get_caller_id()+"I heard %f",data.data)
def normcallback(data):
    global norm
    norm = data.data
    #rospy.loginfo(rospy.get_caller_id()+"I heard %f",data.data)
    
def goaldistcallback(data):
    global target_reached
    if data.data < target_radius:
        target_reached = True
    else:
        target_reached = False
    
    
def potentialfielddriver():
    global bearing
    global norm
    global max_speed
    rospy.init_node('potential_field_driver')

    rospy.Subscriber("potential_field/bearing", Float32, bearingcallback)
    rospy.Subscriber("potential_field/norm", Float32, normcallback)
    rospy.Subscriber("potential_field/goal_distance", Float32, goaldistcallback)
    
    srv = Server(DriverConfig, reconfigurecallback)
    
    cmd_publisher = rospy.Publisher('cmd_car',cmd_car,queue_size=10)
    # spin() simply keeps python from exiting until this node is stopped
    r = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        cmd = cmd_car()
        cmd.steering_angle = kpb*bearing
        cmd.linear_speed = kpn*norm
        if target_reached == True:
            cmd.linear_speed = 0
        elif cmd.linear_speed > max_speed:
            cmd.linear_speed = max_speed
        if fabs(cmd.steering_angle) > 0.3:
            cmd.steering_angle = copysign(0.3, cmd.steering_angle)
        rospy.loginfo("getting: %f %f",bearing,norm)
        rospy.loginfo("publishing: %f  %f", cmd.steering_angle , cmd.linear_speed)
        cmd_publisher.publish(cmd)
        r.sleep()
        
if __name__ == '__main__':
    potentialfielddriver()
