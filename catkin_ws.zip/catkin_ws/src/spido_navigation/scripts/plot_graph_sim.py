#!/usr/bin/env python2
# -*- coding: utf-8 -*-
################################################################################
import rospy
from nav_msgs.msg import Odometry
from spido_pure_interface.msg import cmd_car
from std_msgs.msg import String, Float32, Int32, Float64
from sensor_msgs.msg import Imu, NavSatFix
from geometry_msgs.msg import PointStamped, Point
import tf

from matplotlib import pyplot
import numpy
from math import fabs, tan, cos, sin, hypot, pi, atan, atan2, copysign, asin
import time

from filtrage import filtrage
import sys
################################################################################
real_trajX = numpy.array([])
real_trajY = numpy.array([])
errorDist = numpy.array([])
u1 = numpy.array([])
u2 = numpy.array([])
time_hist = numpy.array([])
trajX = numpy.array([])
trajY = numpy.array([])

# Position
posX = 0.0
posY = 0.0
psi = 0.0
latitude = 0.0
longitude = 0.0
realSpeed = 0
realSteering = 0
targetX = 0
targetY = 0
state_flag = 0

l = 1.5 # distance between axles
earth_radius = 6370.0e3 # earth radius in meters

# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
def fileOpenning(file_name):
    fileX = numpy.array([])
    fileY = numpy.array([])
    fileT = numpy.array([])
    cpt = -1
    seuil = 0.1
    
    Fichier = open(file_name, 'r')
    
    for ligne in Fichier:
        donnees = ligne.rstrip('\n\r').split(";")
        if cpt == -1:
            for i in range(len(donnees)):
                if donnees[i] == 'Latitude':
                    idx_lat = i
                elif donnees[i] == 'Longitude':
                    idx_long = i
                elif donnees[i] == 'T':
                    idx_t = i
            cpt += 1
        elif(hypot(float(donnees[idx_lat]), float(donnees[idx_long])) != 0):
            latitude = float(donnees[idx_lat])*pi/180
            longitude = float(donnees[idx_long])*pi/180
            x = earth_radius*longitude*cos(latitude) - x_origine
            y = earth_radius*latitude - y_origine
            if cpt == 0 :
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            elif( hypot(x-fileX[cpt-1], y-fileY[cpt-1]) != 0 and
                                     hypot(x-fileX[cpt-1], y-fileY[cpt-1]) < 1):
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            
    Fichier.close()
    """
    traj = filtrage(fileX, fileY, fileT)
    trajX = traj[0]
    trajY = traj[1]
    trajX = trajX-trajX[0]+4
    trajY = trajY-trajY[0]+1
    """
    trajX = fileX-fileX[0]+4
    trajY = fileY-fileY[0]-2
    return trajX, trajY
################################################################################
def plot_graph():
    pyplot.clf()
    
    pyplot.figure(1)
    title = (algoName)
    pyplot.suptitle(title)
       
    # figure 1
    pyplot.subplot2grid((3,2), (0,0), rowspan=3)
    pyplot.plot(trajX, trajY, 'b-', label="ref")                  # trajectory to follow
    pyplot.plot(real_trajX, real_trajY, 'r+', label="real_traj")  # real trajectory
    pyplot.scatter(targetX, targetY, s=100, alpha=0.5, color='g') # point targeted on the curve
    pyplot.arrow(posX-l/2*cos(psi), posY-l/2*sin(psi), l*cos(psi), l*sin(psi), head_width=0.1)#vehicle
    pyplot.grid(True)
    pyplot.xlabel('x (m)')
    pyplot.ylabel('y (m)')
    pyplot.legend()
    pyplot.axis('equal')
    # figure 2
    pyplot.subplot2grid((3,2), (0,1))
    average_error = numpy.average(numpy.asarray(errorDist))
    pyplot.plot(time_hist, errorDist)
    pyplot.grid(True)
    pyplot.xlabel('time(s)')
    pyplot.ylabel('Distance to the \nclosest point (m)')
    pyplot.ylim(0, 1)
    #figure 3
    pyplot.subplot2grid((3,2), (1,1))
    pyplot.plot(time_hist, u1)
    pyplot.grid(True)
    pyplot.xlabel('time(s)')
    pyplot.ylabel('Speed(m/s)')
    #figure 4
    pyplot.subplot2grid((3,2), (2,1))
    pyplot.plot(time_hist, u2)
    pyplot.grid(True)
    pyplot.xlabel('time(s)')
    pyplot.ylabel('Steering angle (rad)')
    pyplot.ylim(-0.31, 0.31)
    
    pyplot.show()
    pyplot.pause(0.01) 
################################################################################
def odomCallback(data):
    global posX
    global posY
    global psi
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
    quaternion = (
    data.pose.pose.orientation.x,
    data.pose.pose.orientation.y,
    data.pose.pose.orientation.z,
    data.pose.pose.orientation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    psi = euler[2]
################################################################################
def realCommandCallback(data):
    global realSpeed
    global realSteering
    realSpeed = data.linear_speed
    realSteering = data.steering_angle
################################################################################
def targetCallback(data):
    global targetX
    global targetY
    targetX = data.x
    targetY = data.y
################################################################################
def stateCallback(data):
    global state_flag
    state_flag = data.data
################################################################################
def plot_ros(argv, argv2):
    global real_trajX
    global real_trajY
    global errorDist
    global u1
    global u2
    global time_hist
    global trajX
    global trajY
    global algoName
    
    algoName = argv2
    
    flag_t0 = 0
    
    Path = fileOpenning(argv)
    trajX = Path[0]
    trajY = Path[1]
    
    pyplot.ion()
    pyplot.show()

    rospy.init_node('plot_graph_sim')
    
    rospy.Subscriber("odom", Odometry, odomCallback)
    rospy.Subscriber('cmd_car_safe', cmd_car, realCommandCallback)
    rospy.Subscriber('target_publisher', Point, targetCallback)
    rospy.Subscriber('state', Int32, stateCallback)
    
    # spin() simply keeps python from exiting until this node is stopped
    r = rospy.Rate(10) # 10hz
    
    while not rospy.is_shutdown():
        if state_flag == 0:
            real_trajX = numpy.append(real_trajX, posX)
            real_trajY = numpy.append(real_trajY, posY)
            error = hypot(posX-trajX[0], posY-trajY[0])
            for i in range(1, trajX.size):
                if hypot(posX-trajX[i], posY-trajY[i]) < error:
                    error = hypot(posX-trajX[i], posY-trajY[i])
            errorDist = numpy.append(errorDist, error)
            u1 = numpy.append(u1, realSpeed)
            u2 = numpy.append(u2, realSteering)
            
            now = rospy.get_rostime()
            T2 = now.secs + now.nsecs * pow(10, -9)
            if flag_t0 == 0:
                T0 = T2
                flag_t0 = 1
            time_hist = numpy.append(time_hist, T2-T0)
        
            plot_graph()
        
        elif state_flag == 1:
            plot_graph()
        
        r.sleep()
################################################################################  
if __name__ == '__main__':
    if len(sys.argv) != 3:
        print "Wrong number of arguments : expecting name file and algo name"
    else:
        plot_ros(sys.argv[1], sys.argv[2])
