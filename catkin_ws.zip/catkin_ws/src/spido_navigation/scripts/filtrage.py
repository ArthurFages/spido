#!/usr/bin/env python2
# -*- coding: utf-8 -*-

from pylab import *
import scipy.signal as signal
import numpy
from matplotlib import pyplot
from math import atan2, pi
################################################################################
def filtrage(fileX, fileY, fileT):
    fileBX = numpy.array([])
    fileBY = numpy.array([])
    fileBT = numpy.array([])
    fileCX = numpy.array([])
    fileCY = numpy.array([])
    fileCT = numpy.array([])
    trajX = numpy.array([])
    trajY = numpy.array([])
    trajT = numpy.array([])
    cpt = 0
    seuil = .5
    speed = 0.
    
    s = 0
    for i in range(fileT.size-1):
        s += (fileT[i+1]-fileT[i])
    te = s/fileT.size
    fe = 1.0/te
    
    fc = 0.04
    numtaps = 50
    a = signal.firwin(numtaps, fc, window = "hamming")
    b = [1.0]
    filtered_X = signal.filtfilt(a, b, fileX)
    filtered_Y = signal.filtfilt(a, b, fileY)

    fileBX = numpy.append(fileBX, filtered_X[0])
    fileBY = numpy.append(fileBY, filtered_Y[0])
    fileBT = numpy.append(fileBT, fileT[0])
    for i in range(1, fileX.size):
        dx = filtered_X[i]-filtered_X[i-1]
        dy = filtered_Y[i]-filtered_Y[i-1]
        dt = fileT[i]-fileT[i-1]
        speed = hypot(dx/dt, dy/dt)
        if speed > seuil:
            fileBX = numpy.append(fileBX, filtered_X[i])
            fileBY = numpy.append(fileBY, filtered_Y[i])
            fileBT = numpy.append(fileBT, fileT[i])

    
    cpt = 0
    for i in range(fileBX.size-1):
        cond = hypot(fileBX[i+1]-fileBX[i], fileBY[i+1]-fileBY[i])
        if cond < .5:
            trajX = numpy.append(trajX, fileBX[i])
            trajY = numpy.append(trajY, fileBY[i])
            trajT = numpy.append(trajT, fileBT[i])
    
    for i in range(trajX.size-2):
        cond = hypot(trajX[i+1]-trajX[i], trajY[i+1]-trajY[i])
        if cond > 0.5:
            cpt = i
            break
    
    for i in range(cpt+1):
        trajX = numpy.delete(trajX, 0)
        trajY = numpy.delete(trajY, 0)
        trajT = numpy.delete(trajT, 0)
    """
    trajT_inter = numpy.linspace(0, trajT[trajT.size-1], 100*trajT.size)
    trajX_inter = numpy.interp(trajT_inter, trajT, trajX)
    trajY_inter = numpy.interp(trajT_inter, trajT, trajY)
    
    return trajX_inter, trajY_inter, trajT_inter
    """
    return trajX, trajY, trajT
    
