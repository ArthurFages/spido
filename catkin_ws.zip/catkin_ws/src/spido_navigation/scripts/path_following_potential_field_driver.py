#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
from std_msgs.msg import Float32, Int32, String
from spido_pure_interface.msg import cmd_car
from geometry_msgs.msg import Point, PointStamped
from nav_msgs.msg import Odometry

import tf
from dynamic_reconfigure.server import Server
from spido_navigation.cfg import DriverConfig
from math import fabs, copysign
import numpy
from matplotlib import pyplot
from math import fabs, tan, cos, sin, hypot, pi, atan, atan2, copysign, asin

from filtrage import filtrage

import sys
import matplotlib.patches as patches

#algo = 'robust'
algo = 'robust_bis'
#algo = 'adaptative'
target_curve = 1
bearing = 0.0
norm = 0.0
gain = .05
posX = 0
posY = 0
psi = 0
length = 2.2
axles_dist = 1.5 
wheel_radius = .3
earth_radius = 6370.0e3 # earth radius in meters
# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
def fileOpenning(file_name):
    fileX = numpy.array([])
    fileY = numpy.array([])
    fileT = numpy.array([])
    cpt = -1
    seuil = 0.1
    
    Fichier = open(file_name, 'r')
    
    for ligne in Fichier:
        donnees = ligne.rstrip('\n\r').split(";")
        if cpt == -1:
            for i in range(len(donnees)):
                if donnees[i] == 'Latitude':
                    idx_lat = i
                elif donnees[i] == 'Longitude':
                    idx_long = i
                elif donnees[i] == 'T':
                    idx_t = i
            cpt += 1
        elif(hypot(float(donnees[idx_lat]), float(donnees[idx_long])) != 0):
            latitude = float(donnees[idx_lat])*pi/180
            longitude = float(donnees[idx_long])*pi/180
            x = earth_radius*longitude*cos(latitude) - x_origine
            y = earth_radius*latitude - y_origine
            if cpt == 0 :
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            elif( hypot(x-fileX[cpt-1], y-fileY[cpt-1]) != 0 and
                                     hypot(x-fileX[cpt-1], y-fileY[cpt-1]) < 1):
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            
    Fichier.close()
    
    traj = filtrage(fileX, fileY, fileT)
    trajX = traj[0]
    trajY = traj[1]
    trajX = trajX-trajX[0]+3.5
    trajY = trajY-trajY[0]
    trajT = traj[2]
    
    speedX = numpy.zeros(trajX.size)
    speedY = numpy.zeros(trajY.size)
    for i in range(1, trajX.size-1):
        speedX[i] = (trajX[i]-trajX[i-1])/(trajT[i]-trajT[i-1])
        speedY[i] = (trajY[i]-trajY[i-1])/(trajT[i]-trajT[i-1])
    
    cpt = trajX.size
    s_vect = numpy.zeros(cpt)
    theta_s = numpy.zeros(cpt)
    c = numpy.zeros(cpt)
    dc_ds = numpy.zeros(cpt)

    # s
    for i in range(1, cpt):
        s_vect[i] = s_vect[i-1]+hypot(trajX[i]-trajX[i-1], trajY[i]-trajY[i-1])

    # theta_s
    for i in range(cpt):
        if i<cpt-1:
            angle = atan2(trajY[i+1]-trajY[i], trajX[i+1]-trajX[i])
            if angle < 0 :
                angle += 2*pi
            theta_s[i] = angle
        else:
            angle = theta_s[cpt-2]
            if angle < 0 :
                angle += 2*pi
            theta_s[i] = angle

    # c
    for i in range(cpt):
        if i<cpt-1:
            c[i] = (theta_s[i+1]-theta_s[i])/(s_vect[i+1]-s_vect[i])
        elif i == cpt-1:
            c[i] = c[cpt-2]
            
    # dc/ds
    for i in range(cpt):
        if i<cpt-1:
            dc_ds[i] = (c[i+1]-c[i])/(s_vect[i+1]-s_vect[i])
        else:
            dc_ds[i] = dc_ds[cpt-2]
     
    return trajX, trajY,speedX, speedY, trajT, s_vect, theta_s, c, dc_ds  
################################################################################
def deltaFunction(Kp, Kd, y, theta_tilde, c, dc_ds):
    A = dc_ds*y*tan(theta_tilde)
    B = -Kd*(1-c*y)*tan(theta_tilde)
    C = -Kp*y
    D = c*(1-c*y)*pow(tan(theta_tilde), 2)
    E = c*cos(theta_tilde)/(1-c*y)
    F = pow(cos(theta_tilde),3)/pow((1-c*y),2)
    G = axles_dist*(F*(A+B+C+D)+E)
    return atan(G)
################################################################################
def inverse_commande(v1, v2, phi):
    a = cos(psi)-sin(psi)*tan(phi)-wheel_radius/axles_dist*tan(phi)*sin(phi+psi)
    b = -wheel_radius*sin(psi+phi)
    c = sin(psi)+cos(psi)*tan(phi)+wheel_radius/axles_dist*tan(phi)*cos(phi+psi)
    d = wheel_radius*cos(psi+phi)
    delta = a*d-b*c
    u1 = (d*v1-b*v2)/delta
    u2 = (-c*v1+a*v2)/delta
    return u1, u2
################################################################################
def bearingcallback(data):
    global bearing
    bearing = data.data
################################################################################
def normcallback(data):
    global norm
    if data.data < 1000:
        norm = data.data
    else:
        norm = 0.0
################################################################################
def odomCallback(data):
    global posX
    global posY
    global psi    
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
    quaternion = (
    data.pose.pose.orientation.x,
    data.pose.pose.orientation.y,
    data.pose.pose.orientation.z,
    data.pose.pose.orientation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    psi = euler[2]
################################################################################    
def potentialfielddriver():
    Speed = 8.
    # Command
    cmd = cmd_car()
    u1 = 0.0
    u2 = 0.0
    speedx = 0.
    speedy = 0.
    
    #adaptative
    Kp = 1.
    Kd = 1.
        
    #stabilization
    k1 = 1
    k2 = 1
    
    goal = Point()
    GOAL = False
    close = False
    
    if algo=='robust_bis' or algo=='stabilization':
        dT = 0.
        T0 = 0.
        T1 = 0.
        T2 = 0.
    
    Path = fileOpenning('/home/spido/ROS_catkin_ws/src/gps_novatel/paths/courbe_bis.txt')
    
    trajectoryX = Path[0]
    trajectoryY = Path[1]
    targetX = trajectoryX[0]
    targetY = trajectoryY[0]
    speedX = Path[2]
    speedY = Path[3]
    trajT = Path[4]
    s = Path[5]
    theta_s = Path[6]
    c = Path[7]
    dc_ds = Path[8]
    
    previousx = trajectoryX[0]
    previousy = trajectoryY[0]
    
    rospy.init_node('potential_field_driver')

    rospy.Subscriber("potential_field/bearing", Float32, bearingcallback)
    rospy.Subscriber("potential_field/norm_obs", Float32, normcallback)
    rospy.Subscriber("odom", Odometry, odomCallback)
    
    cmd_publisher = rospy.Publisher('cmd_car_safe',cmd_car,queue_size=10)
    state_publisher = rospy.Publisher('state',Int32,queue_size=10)
    
    goal_pub = rospy.Publisher('target_publisher', Point, queue_size=10)
    
    #DEBUG
    debug = rospy.Publisher('debug', Float32, queue_size=10)
    r = rospy.Rate(10) # 10hz
    
    while not rospy.is_shutdown():
        cmd.linear_speed = u1
        cmd.steering_angle = u2
        if GOAL == False:
            if algo=='adaptative':
                cpt_inf=1
                # The robot is close enought of the trajectory to reproduce it
                while (cpt_inf<trajectoryX.size-1):
                    # Determining the closest point not crossed
                    dist_min = hypot(posX-trajectoryX[cpt_inf], posY-trajectoryY[cpt_inf])
                    for i in range(cpt_inf+1, trajectoryX.size-1):
                        if hypot(posX-trajectoryX[i], posY-trajectoryY[i])<dist_min:
                            dist_min = hypot(posX-trajectoryX[i], posY-trajectoryY[i])
                            if i!=cpt_inf:
                                previousx = goal.x
                                previousy = goal.y
                            cpt_inf = i
                            delta = numpy.array([trajectoryX[cpt_inf]-posX, trajectoryY[cpt_inf]-posY])
                    
                    # targeted point
                    targetX = trajectoryX[cpt_inf]
                    targetY = trajectoryY[cpt_inf]
                    goal.x = targetX + gain*norm*cos(psi+bearing)
                    goal.y = targetY + gain*norm*sin(psi+bearing)
                    
                    s[cpt_inf] = s[cpt_inf-1] + hypot(previousx-goal.x, previousy-goal.y)
                    """
                    theta_s[cpt_inf] = atan2(trajectoryY[cpt_inf+1]-goal.y, trajectoryX[cpt_inf+1]-goal.x)
                    
                    c[cpt_inf] = ( (theta_s[cpt_inf+1]-theta_s[cpt_inf])/
                                                     (s[cpt_inf+1]-s[cpt_inf]) )
                    dc_ds[cpt_inf] = (c[cpt_inf+1]-c[cpt_inf])/(s[cpt_inf+1]-s[cpt_inf])
                    dist_min = hypot(posX-goal.x, posY-goal.y)
                    """
                    # linear_speed and steering_angle computation
                    cmd.linear_speed = Speed
                    theta_tilde = psi-theta_s[cpt_inf]
                    u2 = deltaFunction(Kp, Kd, dist_min, theta_tilde, c[cpt_inf], 
                                                                     dc_ds[cpt_inf])
                    if fabs(u2) > 0.3:
                        u2 = copysign(0.3, u2)
                    cmd.steering_angle = u2
                    
                    # publication
                    cmd_publisher.publish(cmd)
                    goal_pub.publish(goal)
                    state_publisher.publish(0)
            
            elif algo=='robust':
                for i in range(trajectoryX.size):
                    goal.x = targetX + gain*norm*cos(psi+bearing)
                    goal.y = targetY + gain*norm*sin(psi+bearing)
                    # passing conditions:
                    xA = posX + length/2*cos(psi)
                    yA = posY + length/2*sin(psi)
                    xB = posX - length/2*cos(psi)
                    yB = posY - length/2*sin(psi)
                    while( (((xA-trajectoryX[i])*(xB-trajectoryX[i]) > 0) and 
                           ((yA-trajectoryY[i])*(yB-trajectoryY[i]) > 0)) and
                           (hypot(posX-trajectoryX[i], posY-trajectoryY[i])>1) ):
                        # linear_speed and steering_angle computation
                        xA = posX + length/2*cos(psi)
                        yA = posY + length/2*sin(psi)
                        xB = posX - length/2*cos(psi)
                        yB = posY - length/2*sin(psi)
                        N = (xA-posX)*(goal.y-posY)-(yA-posY)*(goal.x-posX)
                        D = hypot(xA-posX, yA-posY)*hypot(goal.x-posX, goal.y-posY)
                        if fabs(N//D) >= 1:
                            u2 = copysign(0.3, N/D)
                        else:
                            u2 = asin(N/D)
                        if fabs(u2) > 0.3:
                            u2 = copysign(0.3, u2)
                        cmd.linear_speed = Speed
                        cmd.steering_angle = u2
                        cmd_publisher.publish(cmd)
                        goal_pub.publish(goal)
                        state_publisher.publish(0)
            
            elif algo=='stabilization' or algo=='robust_bis':
                cpt = 0
                if (hypot(posX - trajectoryX[0], posY - trajectoryY[0]) < target_curve):
                    close = True
                else:
                    while (close == False): # Go close to the curve
                        u2 = atan2((trajectoryY[0]-posY)*cos(psi)-(trajectoryX[0]-posX)*sin(psi),
                                  (trajectoryY[0]-posY)*sin(psi)+(trajectoryX[0]-posX)*cos(psi))
                        if fabs(u2) > 0.3:
                            u2 = copysign(0.3, u2)
                        cmd.linear_speed = 1
                        cmd.steering_angle = u2
                        cmd_publisher.publish(cmd)
                        goal_pub.publish(goal)
                        state_publisher.publish(0)
                        if (hypot(posX - trajectoryX[0], posY - trajectoryY[0]) < target_curve):
                            close = True
                now = rospy.get_rostime()
                T0 = now.secs+now.nsecs*1.0e-9
                while (cpt < trajT.size):
                    targetX = trajectoryX[cpt]
                    targetY = trajectoryY[cpt]
                    goal.x = targetX + gain*norm*cos(psi+bearing)
                    goal.y = targetY + gain*norm*sin(psi+bearing)
                    if( ((targetX != goal.x) or (targetY != goal.y)) and cpt != 0):
                        speedx = ((goal.x-previousx) / (trajT[cpt]-trajT[cpt-1]))
                        speedy = ((goal.y-previousy) / (trajT[cpt]-trajT[cpt-1]))
                    else:
                        speedx = speedX[cpt]
                        speedy = speedY[cpt]
                    # linear_speed and steering_angle computation
                    now = rospy.get_rostime()
                    T1 = T2
                    T2 = now.secs+now.nsecs*1.0e-9
                    dT = T2 - T1
                    if algo == 'stabilization':
                        v1 = speedx - k1*(posX - goal.x)
                        v2 = speedy - k2*(posY - goal.y)
                        commande = inverse_commande(v1, v2, u2)
                        u1 = commande[0]
                        u2 += (commande[1] * dT)
                    elif algo == 'robust_bis':
                        xA = posX + length/2*cos(psi)
                        yA = posY + length/2*sin(psi)
                        xB = posX - length/2*cos(psi)
                        yB = posY - length/2*sin(psi)
                        N = (xA-posX)*(goal.y-posY)-(yA-posY)*(goal.x-posX)
                        D = hypot(xA-posX, yA-posY)*hypot(goal.x-posX, goal.y-posY)
                        if fabs(N/D) < 1:
                            u2 = asin(N/D)
                        else:
                            u2 = copysign(pi/2, N/D)
                        u1 = hypot(speedx, speedy)
                    
                    if u1 < 0:
                        u1 = 0
                    if u1 > Speed:
                        u1 = Speed
                    if fabs(u2) > 0.3:
                        u2 = copysign(0.3, u2)
                    cmd.linear_speed = u1
                    cmd.steering_angle = u2
                    
                    # publication
                    cmd_publisher.publish(cmd)
                    goal_pub.publish(goal)
                    state_publisher.publish(0)
                    
                    Time = T2-T0 + trajT[0]
                    
                    for i in range(cpt, trajT.size-2):
                        if Time>=trajT[i] and Time<trajT[i+1]:
                            if i!=cpt:
                                previousx = goal.x
                                previousy = goal.y
                            cpt = i
                    if Time > trajT[trajT.size-1]:
                        cpt = trajT.size
        
            GOAL = True
        
        else: # Mission accomplished => stop
            goal.x = 0
            goal.y = 0
            goal_pub.publish(goal)
            cmd.steering_angle = 0
            cmd.linear_speed = 0
            cmd_publisher.publish(cmd)
            state_publisher.publish(1)
                
        r.sleep()
################################################################################
if __name__ == '__main__':
    potentialfielddriver()
