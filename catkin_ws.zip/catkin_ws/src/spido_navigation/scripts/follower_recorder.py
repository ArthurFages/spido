#!/usr/bin/env python2
# -*- coding: utf-8 -*-
################################################################################
import rospy
from nav_msgs.msg import Odometry
from spido_pure_interface.msg import cmd_car
from std_msgs.msg import String, Float32, Int32, Float64
from sensor_msgs.msg import Imu, NavSatFix
from geometry_msgs.msg import PointStamped, Point
import tf

from matplotlib import pyplot
import numpy
from math import fabs, tan, cos, sin, hypot, pi, atan, atan2, copysign, asin
import time

from filtrage import filtrage
import sys
################################################################################
real_trajX = numpy.array([])
real_trajY = numpy.array([])
errorDist = numpy.array([])
u1 = numpy.array([])
u2 = numpy.array([])
time_hist = numpy.array([])
trajX = numpy.array([])
trajY = numpy.array([])

# Position
posX = 0.0
posY = 0.0
yaw = 0.0
latitude = 0.0
longitude = 0.0
realSpeed = 0
realSteering = 0
targetX = 0
targetY = 0
algoName = ''
state_flag = 0

earth_radius = 6370.0e3 # earth radius in meters

# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
def fonction_recopy(arg):
    cpt1 = 0
    cpt2 = 0
    cpt_ = 0
    b = '/home/spido/ROS_catkin_ws/src/gps_novatel/replay/'
    for i in range(len(arg), 0, -1):
	if arg[i-1] == "/":
	    cpt_ += 1
	if cpt_ == 1 and arg[i-1] == "/":
	    cpt1 = i
	if cpt_ == 2:
	    cpt2 = i
	    break
    for i in range(cpt1, len(arg)-4):
	b += arg[i]
    return b
################################################################################
def fileOpenning(file_name):
    fileX = numpy.array([])
    fileY = numpy.array([])
    fileT = numpy.array([])
    cpt = -1
    seuil = 0.1
    
    Fichier = open(file_name, 'r')
    
    for ligne in Fichier:
        donnees = ligne.rstrip('\n\r').split(";")
        if cpt == -1:
            for i in range(len(donnees)):
                if donnees[i] == 'Latitude':
                    idx_lat = i
                elif donnees[i] == 'Longitude':
                    idx_long = i
                elif donnees[i] == 'T':
                    idx_t = i
            cpt += 1
        elif(hypot(float(donnees[idx_lat]), float(donnees[idx_long])) != 0):
            latitude = float(donnees[idx_lat])*pi/180
            longitude = float(donnees[idx_long])*pi/180
            x = earth_radius*longitude*cos(latitude) - x_origine
            y = earth_radius*latitude - y_origine
            if cpt == 0 :
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            elif( hypot(x-fileX[cpt-1], y-fileY[cpt-1]) != 0 and
                                     hypot(x-fileX[cpt-1], y-fileY[cpt-1]) < 1):
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            
    Fichier.close()
    """
    traj = filtrage(fileX, fileY, fileT)
    trajX = traj[0]
    trajY = traj[1]
    trajT = traj[2]
    """
    trajX = fileX
    trajY = fileY
    
    return trajX, trajY
################################################################################
def gpsRawCallback(data):
    global posX
    global posY
    longitude = data.longitude
    latitude = data.latitude
    posX = earth_radius*cos(latitude*pi/180)*longitude*pi/180 - x_origine
    posY = earth_radius*latitude*pi/180 - y_origine
################################################################################
def imuYaw(msg):
    global yaw
    yaw = msg.data
################################################################################
def realCommandCallback(data):
    global realSpeed
    global realSteering
    realSpeed = data.linear_speed
    realSteering = data.steering_angle
################################################################################
def targetCallback(data):
    global targetX
    global targetY
    targetX = data.x
    targetY = data.y
################################################################################
def algoNameCallback(data):
    global algoName
    algoName = '_'+data.data+'.txt'
################################################################################
def stateCallback(data):
    global state_flag
    state_flag = data.data
################################################################################
def follower_recorder(argv):
    global real_trajX
    global real_trajY
    global errorDist
    global u1
    global u2
    global time_hist
    global trajX
    global trajY
    
    flag_t0 = 0
    flag_init_file = 0
    
    Path = fileOpenning(argv)
    trajX = Path[0]
    trajY = Path[1]
    
    name_replay = fonction_recopy(argv)
    
    rospy.init_node('follower_recorder')
    
    rospy.Subscriber("gps_data_raw", NavSatFix, gpsRawCallback)
    rospy.Subscriber('imu/yaw', Float64, imuYaw)
    rospy.Subscriber('cmd_car_safe', cmd_car, realCommandCallback)
    rospy.Subscriber('target_publisher', Point, targetCallback)
    rospy.Subscriber('algo_name', String, algoNameCallback)
    rospy.Subscriber('state', Int32, stateCallback)
    
    # spin() simply keeps python from exiting until this node is stopped
    r = rospy.Rate(10) # 10hz
    
    while not rospy.is_shutdown():
        while flag_init_file == 0:
            if algoName != '':
                name_replay += algoName
                Fichier_replay = open(name_replay,'w')
                Fichier_replay.write('trajX;trajY;realX;realY;realU1;realU2;Time\n')
                flag_init_file = 1
        Fichier_replay = open(name_replay,'a')
        if hypot(posX-trajX[0], posY-trajY[0]) < 500:
            real_trajX = numpy.append(real_trajX, posX)
            real_trajY = numpy.append(real_trajY, posY)
            error = hypot(posX-trajX[0], posY-trajY[0])
            for i in range(1, trajX.size):
                if hypot(posX-trajX[i], posY-trajY[i]) < error:
                    error = hypot(posX-trajX[i], posY-trajY[i])
            errorDist = numpy.append(errorDist, error)
            u1 = numpy.append(u1, realSpeed)
            u2 = numpy.append(u2, realSteering)
            
            now = rospy.get_rostime()
            T2 = now.secs + now.nsecs * pow(10, -9)
            if flag_t0 == 0:
                T0 = T2
                flag_t0 = 1
            time_hist = numpy.append(time_hist, T2-T0)
            
            Fichier_replay.write(str(targetX)+';'+str(targetY)+';'+str(posX)+';'+str(posY)+';'+str(realSpeed)+';'+str(realSteering)+';'+str(T2-T0)+'\n')
            
        if state_flag == 1:
            break
        
        r.sleep()
        
    Fichier_replay.close()
################################################################################  
if __name__ == '__main__':
    if len(sys.argv) != 4:
        print "Wrong number of arguments : expecting name file!"
    else:
        follower_recorder(sys.argv[1])
