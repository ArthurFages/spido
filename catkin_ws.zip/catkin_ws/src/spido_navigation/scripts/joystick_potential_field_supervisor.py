#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Joy
from std_msgs.msg import Bool, Float32

new_joy = False
new_joy_timer = False
published = False
deadman_pressed = False
speed_factor = 0.0

def joycallback(joy):
    global deadman
    global speed_factor
    global new_joy
    global new_joy_timer
    if joy.axes[1] > 0:
        speed_factor = joy.axes[1]
    else:
        speed_factor = 0.0
    if joy.buttons[0] == 1:
        deadman = True
    else:
        deadman = False
    new_joy = True

def supervisor():
    global deadman
    global speed_factor
    global new_joy   
    rospy.init_node('supervisor')
    rospy.Subscriber("joy", Joy, joycallback)
    pubdeadman = rospy.Publisher('supervisor/deadman',Bool,queue_size=10)
    pubspeedfactor = rospy.Publisher('supervisor/speed_factor',
                                                          Float32,queue_size=10)
    r = rospy.Rate(10)                                         #loop rate = 10Hz
    while not rospy.is_shutdown():
        if new_joy == True:
            pubdeadman.publish(deadman)
            pubspeedfactor.publish(speed_factor)
            new_joy = False
        r.sleep()

if __name__ == '__main__':
	supervisor()





