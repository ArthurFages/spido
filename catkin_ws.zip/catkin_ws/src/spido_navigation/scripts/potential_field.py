#!/usr/bin/env python2

import rospy
import copy
from std_msgs.msg import String, Float32
from sensor_msgs.msg import LaserScan
from math import cos, sin, sqrt, atan2
from matplotlib import pyplot
import tf
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import PointStamped, Point
from visualization_msgs.msg import Marker
from dynamic_reconfigure.server import Server
from spido_navigation.cfg import PotentialFieldConfig

                                                                 #initialisation
goalx = 0.0
goaly = 0.0
transformed_goalx = 0.0
transformed_goaly = 0.0
goal_force_x = 0.0
goal_force_y = 0.0
near_range = 30
far_range = 50
flag = 0
nearx = []
neary = []
obstacles_forcex = 0.0
obstacles_forcey = 0.0
forcex = 0.0
forcey = 0.0
forcex_display = 0.0
forcey_display = 0.0
old_range = 0.0
obstacle_min_dist = -1.0                                                           
################################################################################
#                               main options                                   #
################################################################################
#display = True
display = False

goal_force_factor = 15
obstacle_force_factor = 15 #unused for now...
            #difference of range between two consecutive rays to take in account
downsample_distance = 1.5 
compass_driver = False
#compass_driver = True
force_type = 2
################################################################################
def reconfigurecallback(config, level):
    global display
    global goal_force_factor
    global obstacle_force_factor
    global downsample_distance
    global force_type
    global near_range
    global far_range
    global a_obstacle_pow_factor
    global b_x_shift
    global c_obstacle_max_influence
    global use_angle_force_reducer
    global angle_force_reducer
    near_range = config.near_range
    far_range = config.far_range
    force_type = config.force_type
    display = config.display
    goal_force_factor = config.goal_force_factor
    obstacle_force_factor = config.obstacle_force_factor
    downsample_distance = config.downsample_distance
    a_obstacle_pow_factor = config.a_obstacle_pow_factor
    b_x_shift = config.b_x_shift
    c_obstacle_max_influence = config.c_obstacle_max_influence
    use_angle_force_reducer = config.use_angle_force_reducer
    angle_force_reducer = config.angle_force_reducer
    return config
################################################################################
def compute_obstacle_force(distance,angle):
    ''' returns the 'force_factor' for a given distance to the obstacle.
    the force calculated will have force_factor as a norm and the oposite
    direction to the obstacle (repulsive obstacles). '''
    global obstacle_force_factor
    global force_type
    if force_type == 1:                    #working with spido gazebo simulation
        if distance > 2:
            force_factor = - 6.25/pow((distance),2) * obstacle_force_factor
        else :
            force_factor = - 6.25/pow((distance),2) * obstacle_force_factor
    elif force_type == 2:                                      #used for pioneer
        if distance > 2.5:
            force_factor = 0
        else :
            force_factor = - 1/pow((distance + 0.8),4) * obstacle_force_factor
    elif force_type == 3:
        if distance < c_obstacle_max_influence:
            force_factor = - 1/pow((distance + b_x_shift),
                                  a_obstacle_pow_factor) * obstacle_force_factor
            if use_angle_force_reducer == True:
                force_factor = force_factor * (3.15 -
                                               angle_force_reducer * abs(angle))
        else:
            force_factor = 0
    elif force_type == 4:
        if distance > 2:
            force_factor = - 1/pow((distance),2) * obstacle_force_factor
        else :
            force_factor = - 1/pow((distance),2) * obstacle_force_factor
    return force_factor
       
################################################################################
def clickedpointcallback(data):
    global goalx
    global goaly
    global compass_driver
    compass_driver = False
    rospy.loginfo("Goal changed!")
    goalx = data.point.x
    goaly = data.point.y
################################################################################
def goalcallback(data):
    global transformed_goalx
    global transformed_goaly
    global compass_driver
    compass_driver = True
    transformed_goalx = data.point.x
    transformed_goaly = data.point.y
################################################################################
def lasercallback(data):
    global flag
    global nearx
    global neary
    global farx
    global fary
    global obstacles_forcex
    global obstacles_forcey
    global forcex
    global forcey
    global goal_force_x
    global goal_force_y
    global old_range
    global obstacle_min_dist
    global near_range
    global far_range
    angle_index=0.0;
    nearx = []
    neary = []
    farx = []
    fary = []
    xi = 0.0
    yi = 0.0
    j = 0
    forcex = 0.0
    forcey = 0.0
    min_dist = -1.0
    n = 0                                        #remind the last point recorded
#avoid plotting half laserscan data causing dimension problems
#TODO: buffer all the variables to be plotted ...
    flag = 0 
    for i in range(0,len(data.ranges)):
        angle_index = data.angle_increment*i
        foce_factor = 0.0
        if min_dist < 0 or min_dist > data.ranges[i]:
            min_dist = data.ranges[i]
                                            #distance to the last point recorded
        d = sqrt(pow(data.ranges[i],2)+pow(data.ranges[n],2)-
                2*data.ranges[i]*data.ranges[n]*cos((i-n)*data.angle_increment))
        if d > downsample_distance:
            n = i
            if data.ranges[i] < near_range:
                xi = -data.ranges[i]*cos(angle_index)
                yi = -data.ranges[i]*sin(angle_index)
                nearx.append(xi)
                neary.append(yi)
                #compute the force induced by the obstacle
                force_factor = compute_obstacle_force(data.ranges[i],angle_index)
                forcex = forcex + force_factor*xi
                forcey = forcey + force_factor*yi
                j = j + 1
                
            elif data.ranges[i] < far_range:
                farx.append(-data.ranges[i]*cos(angle_index))
                fary.append(-data.ranges[i]*sin(angle_index))
                j = j + 1
            old_range = data.ranges[i]
    obstacle_min_dist = min_dist
    flag = 1
    #compute force induced by goal point----------------------------------------
    goal_distance = sqrt(pow(transformed_goalx,2)+pow(transformed_goaly,2))
    if goal_distance > 1:
        goal_force_x = goal_force_factor * transformed_goalx/goal_distance
        goal_force_y = goal_force_factor * transformed_goaly/goal_distance
    else:
        goal_force_x = goal_force_factor * transformed_goalx
        goal_force_y = goal_force_factor * transformed_goaly
               #TODO: do something to stop when getting close enouth to the goal
        rospy.loginfo("getting close to the goal :) ")
    
################################################################################    
def force_display(forcex,forcey):
    global forcex_display
    global forcey_display
    disp_scale = 50.0/20/2
    max_disp_force = 20
    force_norm = sqrt(pow(forcex,2)+pow(forcey,2))
    if force_norm > max_disp_force:
        forcex_display = disp_scale * max_disp_force * forcex/force_norm
        forcey_display = disp_scale * max_disp_force * forcey/force_norm
    elif force_norm > 1:
        forcex_display = disp_scale * forcex
        forcey_display = disp_scale * forcey
    else:
        forcex_display = forcex
        forcey_display = forcey
################################################################################
def plot_graph():
    pyplot.clf()
              #plot the corners of the laserscan (fixed scale of the figure)
    pyplot.plot(-far_range,-far_range)
    pyplot.plot(far_range,far_range)
    pyplot.plot(nearx,neary, 'r.',label='acc.x')
    pyplot.plot(farx,fary, 'b.',label='acc.x')
    pyplot.scatter(0, 0, s=600, alpha=0.5, color='b')
    pyplot.arrow(0,0,0.5,0,head_width=2.5,head_length=3,color='k')
    force_display(forcex,forcey)
    pyplot.arrow(0,0,forcex_display,forcey_display,head_width=1.5,head_length=2,
                                                                      color='r')
    pyplot.scatter(transformed_goalx, transformed_goaly, s=600, alpha=0.5,
                                                                      color='g')
    force_display(goal_force_x,goal_force_y)
    pyplot.arrow(0,0,forcex_display,forcey_display,head_width=1.5,head_length=2,
                                                                      color='k')
    force_display(goal_force_x+forcex,goal_force_y+forcey)
    pyplot.arrow(0,0,forcex_display,forcey_display,head_width=1.5,head_length=2,
                                                                      color='g')
    pyplot.show()
    pyplot.pause(0.01)        
################################################################################
def markerspublish(pubgoalmarker, pubobstaclemarker, pubforcemarker):
    origin = Point()
    goalend = Point()
    obstacleend = Point()
    forceend = Point()
    goalend.x = goal_force_x
    goalend.y = goal_force_y
    obstacleend.x = forcex
    obstacleend.y = forcey
    forceend.x = goal_force_x + forcex
    forceend.y = goal_force_y + forcey
    rospy.loginfo("fx: %f, fy: %f, gfx: %f, gfy: %f", forcex, forcey, goal_force_x, goal_force_y)
    rospy.loginfo("forceend.x: %f, forceend.y: %f", forceend.x, forceend.y)
    goalmarker = Marker()
    goalmarker.type = 0
    goalmarker.ns = "potential_field"
    goalmarker.header.stamp = rospy.Time.now()
    goalmarker.header.frame_id = "velodyne"
    goalmarker.lifetime.secs = 0.2
    goalmarker.color.a = 1.0
    goalmarker.scale.x = 0.1
    goalmarker.scale.y = 0.3
    goalmarker.scale.z = 0.3
    goalmarker.points.append(origin)
    
    obstaclemarker = Marker()
    forcemarker = Marker()
    obstaclemarker = copy.deepcopy(goalmarker)           #copying global setup to other markers
    forcemarker = copy.deepcopy(goalmarker) 

    goalmarker.points.append(goalend)
    goalmarker.color.g = 1.0
    
    obstaclemarker.points.append(obstacleend)
    obstaclemarker.color.r = 1.0
    
    forcemarker.points.append(forceend)
    forcemarker.color.b = 1.0
    
    pubgoalmarker.publish(goalmarker)
    pubobstaclemarker.publish(obstaclemarker)
    pubforcemarker.publish(forcemarker)
    rospy.loginfo("publishing markers")
################################################################################
def potentialfield():
    global flag
    global forcex_display
    global forcey_display
    global goalx
    global goaly
    global transformed_goalx
    global transformed_goaly
    global compass_driver
    global obstacle_min_dist
    rospy.init_node('potential_field')
    
    laserscan_topic='/spido/laser/scan'
    if rospy.has_param('potential_field/laserscan_topic'):
        laserscan_topic = rospy.get_param('potential_field/laserscan_topic')
    rospy.loginfo("using laserscan topic : %s", laserscan_topic)
    
    rospy.Subscriber(laserscan_topic, LaserScan, lasercallback)
    tflistener = tf.TransformListener()
           #Subscribe to the /clicked_point topic to get goal position from Rviz
    rospy.Subscriber("clicked_point", PointStamped, clickedpointcallback)
                         #Subscribe to direct goal position in the robot's frame
    rospy.Subscriber("goal_transformed", PointStamped, goalcallback)
    pubbearing = rospy.Publisher('potential_field/bearing',Float32,
                                                                  queue_size=10)
    pubnorm = rospy.Publisher('potential_field/norm',Float32,queue_size=10)
    pubmindist = rospy.Publisher('obstacle_min_dist',Float32,queue_size=10)
                    #publisher sending the distance remaining to the goal target
    pubgoaldist = rospy.Publisher('potential_field/goal_distance',
                                                          Float32,queue_size=10)
    pubgoalmarker = rospy.Publisher('potential_field/goal_maker', Marker)
    pubobstaclemarker = rospy.Publisher('potential_field/obstacles_maker',
                                                                         Marker)
    pubforcemarker = rospy.Publisher('potential_field/force_maker', Marker)
    srv = Server(PotentialFieldConfig, reconfigurecallback)
                                                #allow dynamic dispay for pyplot
    if display == True: 
        pyplot.ion()
        pyplot.show()
                                              #setup loop rate for the main loop
    r = rospy.Rate(10)                                         #loop rate = 10Hz
    while not rospy.is_shutdown(): 
                  #get the goal position and transform it into hokuyo_link frame
        if compass_driver == False:
            try:
                now = rospy.Time.now()
                   #wait for the next available transform between the two frames
                tflistener.waitForTransform('world', 'hokuyo_link', now,
                                                            rospy.Duration(4.0))
                p = PointStamped()
                p.header.stamp = rospy.Time()
                p.header.frame_id = "world"
                p.point.x = goalx
                p.point.y = goaly
                p.point.z = 0
                p = tflistener.transformPoint('hokuyo_link',p)
                transformed_goalx = p.point.x
                transformed_goaly = p.point.y
            except (tf.LookupException, tf.ConnectivityException,tf.Exception):
                             #show error if the tf transform couldnt be obtained
                rospy.loginfo("tf Exception!, shouldn't happend at hight frequency")
                #continue
        else:
                rospy.loginfo("working with compass driver")
        if flag == 1 and display == True:
                 #plot the graph if the data is available and plotting activated
            plot_graph()
        flag = 0
         #compute bearing angle, norm of the computed force and distance to goal
        bearing = atan2(goal_force_y+forcey,goal_force_x+forcex)
        norm = sqrt(pow(goal_force_x+forcex,2)+pow(goal_force_y+forcey,2))
        goal_distance = sqrt(pow(transformed_goalx,2)+pow(transformed_goaly,2))
                                               #publih bearing norm and distance
        pubgoaldist.publish(goal_distance)
        pubbearing.publish(bearing)
        pubnorm.publish(norm)
        pubmindist.publish(obstacle_min_dist)
                                                                #publish markers
        markerspublish(pubgoalmarker, pubobstaclemarker, pubforcemarker)
        r.sleep()
    
if __name__ == '__main__':
    try:
        potentialfield()
    except rospy.ROSInterruptException: pass
