#!/usr/bin/env python2
# -*- coding: utf-8 -*-
import rospy
from std_msgs.msg import Float32, Int32, String
from spido_pure_interface.msg import cmd_car
from geometry_msgs.msg import Point, PointStamped
from nav_msgs.msg import Odometry

import tf
from dynamic_reconfigure.server import Server
from spido_navigation.cfg import DriverConfig
from math import fabs, copysign
import numpy
from matplotlib import pyplot
from math import fabs, tan, cos, sin, hypot, pi, atan, atan2, copysign, asin

from filtrage import filtrage

import sys
import matplotlib.patches as patches

trajX = numpy.array([])
trajY = numpy.array([])
obstacleX = numpy.array([])
obstacleY = numpy.array([])
real_trajX = numpy.array([])
real_trajY = numpy.array([])
errorDist = numpy.array([])
u1 = numpy.array([])
u2 = numpy.array([])

obsNorm = 0.0
obstacle_x = 0.0
obstacle_y = 0.0
posX = 0
posY = 0
psi = 0
targetX = 0.
targetY = 0.
realSpeed = 0.
realSteering = 0.
state_flag = 1
width = 1.6
length = 2.2

earth_radius = 6370.0e3 # earth radius in meters
# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*cos((48.+51./60+30./3600)*pi/180)*pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*pi/180*(48.+51./60+30./3600)
################################################################################
def fileOpenning(file_name):
    fileX = numpy.array([])
    fileY = numpy.array([])
    fileT = numpy.array([])
    cpt = -1
    seuil = 0.1
    
    Fichier = open(file_name, 'r')
    
    for ligne in Fichier:
        donnees = ligne.rstrip('\n\r').split(";")
        if cpt == -1:
            for i in range(len(donnees)):
                if donnees[i] == 'Latitude':
                    idx_lat = i
                elif donnees[i] == 'Longitude':
                    idx_long = i
                elif donnees[i] == 'T':
                    idx_t = i
            cpt += 1
        elif(hypot(float(donnees[idx_lat]), float(donnees[idx_long])) != 0):
            latitude = float(donnees[idx_lat])*pi/180
            longitude = float(donnees[idx_long])*pi/180
            x = earth_radius*longitude*cos(latitude) - x_origine
            y = earth_radius*latitude - y_origine
            if cpt == 0 :
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            elif( hypot(x-fileX[cpt-1], y-fileY[cpt-1]) != 0 and
                                     hypot(x-fileX[cpt-1], y-fileY[cpt-1]) < 1):
                fileX = numpy.append(fileX, x)
                fileY = numpy.append(fileY, y)
                fileT = numpy.append(fileT, float(donnees[idx_t]))
                cpt += 1
            
    Fichier.close()
    
    traj = filtrage(fileX, fileY, fileT)
    trajX = traj[0]
    trajY = traj[1]
    trajX = trajX-trajX[0]+3.5
    trajY = trajY-trajY[0]
    trajT = traj[2]
            
    return trajX, trajY, trajT
################################################################################
def plot_graph():
    pyplot.clf()
    pyplot.figure(1)
    """title = ("Path planning and robust tracking for a car-like robot\n"
            +"M. Egerstedt, X. Hu, H. Rehbinder and A. Stotsky\n")"""
    title = ("Stabilization of Trajectories for a Nonconstrained Point\n"
            +"P. Morin and C. Samson\n"
            +"k1 = 1 and k2 = 1")
    pyplot.suptitle(title)
    
    # figure 1
    ax1 = pyplot.subplot2grid((3,2), (0,0), rowspan=3)
    pyplot.plot(trajX, trajY, 'b-') # trajectory to follow
    pyplot.plot(real_trajX, real_trajY, 'r-') # real trajectory
    #vehicle
    xa = posX-length/2*cos(psi)-width/2*sin(psi)
    xap = xa+length*cos(psi)
    ya = posY-length/2*sin(psi)+width/2*cos(psi)
    yap = ya+length*sin(psi)
    xb = posX-length/2*cos(psi)+width/2*sin(psi)
    xbp = xb+length*cos(psi)
    yb = posY-length/2*sin(psi)-width/2*cos(psi)
    ybp = yb+length*sin(psi)
    pyplot.plot([xa, xap], [ya, yap], 'k')
    pyplot.plot([xb, xbp], [yb, ybp], 'k')
    pyplot.plot([xa, xb], [ya, yb], 'k')
    pyplot.plot([xap, xbp], [yap, ybp], 'k')
    
    pyplot.scatter(targetX, targetY, s=100, alpha=0.5, color='b') # target point on the curve
    pyplot.grid(True)
    # obstacle
    ax1.add_patch(
		patches.Rectangle(
			(10, -2),   # (x,y)
			2,          # width
			2,          # height
			fill=False,
            color='m'
		)
	)
    ax1.add_patch(
		patches.Rectangle(
			(17, 9),   # (x,y)
			2,          # width
			2,          # height
			fill=False,
            color='m'
		)
	)
    pyplot.plot(obstacleX, obstacleY, 'rx')
    pyplot.xlabel('x (m)')
    pyplot.ylabel('y (m)')
    pyplot.axis('equal')
    # figure 2
    pyplot.subplot2grid((3,2), (0,1))
    pyplot.plot(errorDist)
    pyplot.grid(True)
    pyplot.xlabel('Number of iterations')
    pyplot.ylabel('Distance to the \nclosest point (m)')
    #figure 3
    pyplot.subplot2grid((3,2), (1,1))
    pyplot.plot(u1)
    pyplot.grid(True)
    pyplot.xlabel('Number of iterations')
    pyplot.ylabel('Speed (m/s)')
    #figure 4
    pyplot.subplot2grid((3,2), (2,1))
    pyplot.plot(u2)
    pyplot.grid(True)
    pyplot.xlabel('Number of iterations')
    pyplot.ylabel('Steering angle (rad)')
    pyplot.ylim(-0.31, 0.31)
    
    pyplot.show()
    pyplot.pause(0.01) 
################################################################################
def obsDistCallback(data):
    global obsNorm
    obsNorm = data.data
################################################################################
def obsCallback(data):
    global obstacle_x
    global obstacle_y
    obstacle_x = data.x
    obstacle_y = data.y
################################################################################
def odomCallback(data):
    global posX
    global posY
    global psi    
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
    quaternion = (
    data.pose.pose.orientation.x,
    data.pose.pose.orientation.y,
    data.pose.pose.orientation.z,
    data.pose.pose.orientation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    psi = euler[2]
################################################################################
def targetCallback(data):
    global targetX
    global targetY
    targetX = data.x
    targetY = data.y
################################################################################
def realCommandCallback(data):
    global realSpeed
    global realSteering
    realSpeed = data.linear_speed
    realSteering = data.steering_angle
################################################################################    
def stateCallback(data):
    global state_flag
    state_flag = data.data
################################################################################
def main_plot():
    global trajX
    global trajY
    Path = fileOpenning('/home/spido/ROS_catkin_ws/src/gps_novatel/paths/test6_all.txt')
    Path = fileOpenning('/home/spido/ROS_catkin_ws/src/gps_novatel/paths/courbe_bis.txt')
    trajX = Path[0]
    trajY = Path[1]

    global obstacleX
    global obstacleY
    flag_begin = 0

    global real_trajX
    global real_trajY

    global errorDist
    error = 0

    global u1
    global u2
    
    pyplot.ion()
    pyplot.show()
    
    rospy.init_node('potential_field_plot')

    rospy.Subscriber('target_publisher', Point, targetCallback)
    rospy.Subscriber("/obstacle/dist", Float32, obsDistCallback)
    rospy.Subscriber("/obstacle/coord", Point, obsCallback)
    rospy.Subscriber('cmd_car_safe', cmd_car, realCommandCallback)
    rospy.Subscriber("odom", Odometry, odomCallback)
    rospy.Subscriber('state', Int32, stateCallback)

    r = rospy.Rate(100) # 100hz

    while not rospy.is_shutdown():
        if state_flag == 0:
            """
            if (obsNorm < 30 and obsNorm > 1 and flag_begin == 0):
                obstacleX = numpy.append(obstacleX, obstacle_x)
                obstacleY = numpy.append(obstacleY, obstacle_y)
                flag_begin = 1
            if flag_begin == 1:
                dist_min = hypot(obstacle_x-obstacleX[0], obstacle_y-obstacleY[0])
                for i in range(1, obstacleX.size):
                    if hypot(obstacle_x-obstacleX[i], obstacle_y-obstacleY[i])<dist_min:
                        dist_min = hypot(obstacle_x-obstacleX[i], obstacle_y-obstacleY[i])
            if (obsNorm < 30 and obsNorm > 1 
                                            and dist_min>0.1
                                                and flag_begin == 1):
                obstacleX = numpy.append(obstacleX, obstacle_x)
                obstacleY = numpy.append(obstacleY, obstacle_y)
            """
            if (obsNorm < 30 and obsNorm > 1):
                obstacleX = numpy.append(obstacleX, obstacle_x)
                obstacleY = numpy.append(obstacleY, obstacle_y)
            real_trajX = numpy.append(real_trajX, posX)
            real_trajY = numpy.append(real_trajY, posY)
            error = hypot(posX-trajX[0], posY-trajY[0])
            for i in range(1, trajX.size):
                if hypot(posX-trajX[i], posY-trajY[i]) < error:
                    error = hypot(posX-trajX[i], posY-trajY[i])
            errorDist = numpy.append(errorDist, error)
            u1 = numpy.append(u1, realSpeed)
            u2 = numpy.append(u2, realSteering)

        plot_graph()
                
        r.sleep()
################################################################################
if __name__ == '__main__':
    main_plot()
