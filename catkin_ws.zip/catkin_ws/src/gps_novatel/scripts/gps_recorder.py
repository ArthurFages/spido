#!/usr/bin/env python2
# -*- coding: utf-8 -*-

################################################################################
# Record gps and imu data in a file
################################################################################

import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
from sensor_msgs.msg import Imu, NavSatFix

from matplotlib import pyplot
import numpy as np

import sys

# Position
posX = 0.0
posY = 0.0
posZ = 0.
longitude = 0.
latitude = 0.
altitude = 0.
quaternion_x = 0.
quaternion_y = 0.
quaternion_z = 0.
quaternion_w = 0.
roll = 0.0
pitch = 0.0
yaw = 0.0
acc_x = 0.
acc_y = 0.
acc_z = 0.
ang_vel_x = 0.
ang_vel_y = 0.
ang_vel_z = 0.
velocity_x = 0.
velocity_y = 0.
velocity_z = 0.

earth_radius = 6370.0e3 # rayon de la Terre en m

################################################################################
def convertTime(t1, t2, T1, T2, cpt):
    if cpt==0:
        return 0
    elif t2 >= t1 :
        T = (t2 - t1 + (T2 - T1) * pow(10,9)) # time in ns
        return T * pow(10, -9)
    else :
        T = (t2 - t1 + pow(10,9) + (T2 - T1 - 1) * pow(10,9)) * pow(10, -9)
        return T
################################################################################
def odomCallback(data):
    global posX
    global posY
    global posZ
    global velocity_x
    global velocity_y
    global velocity_z
    posX = data.pose.pose.position.x
    posY = data.pose.pose.position.y
    posZ = data.pose.pose.position.z
    velocity_x = data.twist.twist.linear.x
    velocity_y = data.twist.twist.linear.y
    velocity_z = data.twist.twist.linear.z
################################################################################
def gpsCallback(data):
    global longitude
    global latitude
    global altitude
    longitude = data.longitude
    latitude = data.latitude
    altitude = data.altitude
################################################################################
def imuCallback(data):
    global quaternion_x
    global quaternion_y
    global quaternion_z
    global quaternion_w
    global acc_x
    global acc_y
    global acc_z
    global ang_vel_x
    global ang_vel_y
    global ang_vel_z
    quaternion_x = data.orientation.x
    quaternion_y = data.orientation.y
    quaternion_z = data.orientation.z
    quaternion_w = data.orientation.w
    acc_x = data.linear_acceleration.x
    acc_y = data.linear_acceleration.y
    acc_z = data.linear_acceleration.z
    ang_vel_x = data.angular_velocity.x
    ang_vel_y = data.angular_velocity.y
    ang_vel_z = data.angular_velocity.z
################################################################################
def imuRoll(msg):
    global roll
    roll = msg.data
################################################################################
def imuPitch(msg):
    global pitch
    pitch = msg.data
################################################################################
def imuYaw(msg):
    global yaw
    yaw = msg.data
################################################################################
def pathRecorder(argv):
    # Current position
    global posX
    global posY
    global posZ
    global longitude
    global latitude
    global altitude
    global trajX 
    global trajY
    trajX = np.array([])
    trajY = np.array([])
    cpt = 0
    t1 = 0
    t2 = 0
    T1 = 0
    T2 = 0
    tmp = 0
    Tmp = 0
    T = 0
    
    rospy.init_node('gps_recorder')
    
    rospy.Subscriber("gps_data", Odometry, odomCallback)
    rospy.Subscriber("gps_data_raw", NavSatFix, gpsCallback)
    rospy.Subscriber('imu/data', Imu, imuCallback)
    rospy.Subscriber('imu/roll', Float64, imuRoll)
    rospy.Subscriber('imu/pitch', Float64, imuPitch)
    rospy.Subscriber('imu/yaw', Float64, imuYaw)
    
    r = rospy.Rate(100) # 100hz
    
    Fichier_all = open('/home/spido/ROS_catkin_ws/src/gps_novatel/paths/'+argv+'.txt','w')
    Fichier_all.write('Latitude;Longitude;Altitude;'
                                                    +'Qx;Qy;Qz;Qw;'
                                                    +'roll;pitch;yaw;'
                                                    +'Vely;Velx;Velz;' 
                                              +'Acc_x;Acc_y;Acc_z;Vel_ang_x;Vel_ang_y;Vel_ang_z;'
                                                                     +'T\n')
    # velx and vely are swithced somewhere...
    while not rospy.is_shutdown():
        now = rospy.get_rostime()
        tmp = t2
        Tmp = T2
        T2 = now.secs
        t2 = now.nsecs
        T1 = Tmp
        t1 = tmp
        T += convertTime(t1, t2, T1, T2, cpt)
        Tstr = str(T)
        
        Latitude = str(latitude)
        Longitude = str(longitude)
        Altitude = str(altitude)
        Velx = str(velocity_x) # there is a problem: x and y are inverted
        Vely = str(velocity_y)
        Velz = str(velocity_z)
        
        Qx = str(quaternion_x)
        Qy = str(quaternion_y)
        Qz = str(quaternion_z)
        Qw = str(quaternion_w)
        Roll = str(roll)
        Pitch = str(pitch)
        Yaw = str(yaw)
        Acc_x = str(acc_x)
        Acc_y = str(acc_y)
        Acc_z = str(acc_z)
        Vel_ang_x = str(ang_vel_x)
        Vel_ang_y = str(ang_vel_y)
        Vel_ang_z = str(ang_vel_z)
        
        Fichier_all.write(Latitude+';'+Longitude+';'+Altitude+';'
                                                    +Qx+';'+Qy+';'+Qz+';'+Qw+';'
                                                    +Roll+';'+Pitch+';'+Yaw+';'
                                                     +Velx+';'+Vely+';'+Velz+';'
                                              +Acc_x+';'+Acc_y+';'+Acc_z+';'
                                              +Vel_ang_x+';'+Vel_ang_y+';'+Vel_ang_z+';'
                                                                     +Tstr+'\n')
        
        cpt += 1
        r.sleep()
        
    Fichier_all.close()
    
################################################################################  
if __name__ == '__main__':
    if len(sys.argv) != 4:
        print "Wrong number of arguments : expecting one"
    else:
        pathRecorder(sys.argv[1])
