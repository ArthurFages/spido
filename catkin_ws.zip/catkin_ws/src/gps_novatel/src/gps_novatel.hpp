#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>

#define earth_radius  (6370.0e3)    // m
#define PI (3.1415926)


using namespace std;

class GpsModule
{
  public:
    double   universal_time;
    double   position_x;
    double   position_y;
    double   position_z;
    double   origine_x;
    double   origine_y;
    double   origine_z;

    double   position_x_prev;
    double   position_y_prev;
    
    double   velocity_x;
    double   velocity_y;
    double   velocity_z;

    double   heading;
    
  protected:
    double   longitude;
    double   latitude;
    double   hauteur;

    string  datum_id;
    string  base_station_id;

    double   ondulation;
    double   sigma_longitude;
    double   sigma_latitude;
    double   sigma_hauteur;

    double   diff_age;
    double   solution_age;
    int     nb_sat_tracked;
    int     nb_sat_used;
    int     nb_sat_GLONASS_L1;
    int     nb_sat_GLONASS_L1_L2;
    int     int_reserved;
    int     ext_sol_status;
    int     signal_mask;           

    int     origine_flag;

    int     gps_uart;

  public:

    GpsModule(const char *device_name)
    {
      struct termios termios_cfg;

       gps_uart = open(device_name, O_RDWR|O_NOCTTY);  //|O_NONBLOCK 
       if (gps_uart< 0)  
         cout << "error\n";

       tcgetattr(gps_uart,&termios_cfg); 
                
                   
       termios_cfg.c_cflag = B115200| CS8 | CLOCAL | CREAD; // 8 bit + 1 stop 
       termios_cfg.c_iflag = IGNPAR | ICRNL; 
       termios_cfg.c_oflag = 0; 
                          
       /* positionne le mode de lecture (non canonique, sans echo, ...) */ 
       termios_cfg.c_lflag = ICANON; 
                                 
       termios_cfg.c_cc[VTIME]    = 100;   /* timer inter-caractères non utilisé */ 
       termios_cfg.c_cc[VMIN]     = 0;   /* read bloquant jusqu'à ce que 1 */ 
       /* caractères
        * soient
        * lus
        * */ 
     
       tcflush(gps_uart, TCIOFLUSH); 
       tcsetattr(gps_uart,TCSANOW,&termios_cfg);
                                                                              
      origine_flag = 1;    
      heading = 0;
    }

    ~GpsModule()
    {
      char *buffer = "unlogall com1\n"; 
      write(gps_uart, buffer, strlen(buffer)); 
      //cout << buffer;
      close(gps_uart);
      cout << "Release GPS driver. Bye Bye...\n";
    }

    bool IsOpen() 
    {
      return gps_uart;
    }

    void uart_write(char *buffer)
    {
      write(gps_uart, buffer, strlen(buffer)); 
      cout << buffer;
    }

    void InitBestposa()
    {
        uart_write("log com1 bestposa ontime .05\n");   // 20 Hz
        uart_write("log com1 bestvela ontime .05\n");        // 20 Hz
        uart_write("log com1 gphdt onchanged\n");         // Async
    }
    
    double getLatitude()
    {
        return latitude;
    }
    
    double getLongitude()
    {
        return longitude;
    }
    
    double getHauteur()
    
    {
        return hauteur;
    }

    void ProcessData()
    {
      char   car;
      string token;
      char   buffer[256];

      int len = read(gps_uart, buffer, 256);
      buffer[len] = 0;
      //std::cout << buffer << std::endl;

      string line(buffer);
      istringstream iss(line);
      getline(iss, token, ',');

      if(token.compare("#BESTPOSA")==0)
      {
        string header;
        string solution_status;
        string position_type;


        // Skip message Header
        getline(iss, header, ';');
        getline(iss, solution_status, ',');
        getline(iss, position_type, ',');

        // Collect data
        iss >> latitude; iss >> car;
        iss >> longitude; iss >> car;
        iss >> hauteur; iss >> car;
        iss >> ondulation; iss >> car;
        getline(iss, datum_id, ',');
        iss >> sigma_latitude; iss >> car;
        iss >> sigma_longitude; iss >> car;
        iss >> sigma_hauteur; iss >> car;
        getline(iss, base_station_id, ',');
        iss >> diff_age; iss >> car;
        iss >> solution_age; iss >> car;
        iss >> nb_sat_tracked; iss >> car;
        iss >> nb_sat_used; iss >> car;
        iss >> nb_sat_GLONASS_L1; iss >> car;
        iss >> nb_sat_GLONASS_L1_L2; iss >> car;
        iss >> int_reserved; iss >> car;
        iss >> ext_sol_status; iss >> car;
        iss >> signal_mask; iss >> car;           
    
        // Compute relative position
        position_x = earth_radius*cos(latitude*PI/180.)*PI/180.*longitude;
        position_y = earth_radius*PI/180.*latitude;
        position_z = hauteur;

        if(origine_flag)
        {
          origine_flag = 0;
          origine_x = position_x;
          origine_y = position_y;
          origine_z = position_z;
          position_x_prev = 0;
          position_y_prev = 0;
        }
        
        position_x -= origine_x;
        position_y -= origine_y;
        position_z -= origine_z;

        // cap
        double dx = position_x-position_x_prev;
        double dy = position_y-position_y_prev;

        if(sqrt(dx*dx+dy*dy)>.05)
        {
          position_x_prev = position_x;
          position_y_prev = position_y;
          heading = atan2(dy, dx);
        }

        /*cout << solution_status << "   ";
        cout << "x: " << position_x; 
        cout << " y: " << position_y; 
        cout << " th: " << heading; 
        cout << endl;*/
      }

      if(token.compare("#BESTVELA")==0)
      {
        string header;
        string solution_status;
        string velocity_type;
        double latence;
        double age;
        double speed_xy;
        double speed_dir;
        double speed_z;


        // Skip message Header
        getline(iss, header, ';');
        getline(iss, solution_status, ',');
        getline(iss, velocity_type, ',');

        // Collect data
        iss >> latence; iss >> car;
        iss >> age; iss >> car;
        iss >> speed_xy; iss >> car;
        iss >> speed_dir; iss >> car;
        iss >> speed_z; iss >> car;

        velocity_x = speed_xy * cos(speed_dir*PI/180.);
        velocity_y = speed_xy * sin(speed_dir*PI/180.);
        velocity_z = speed_z;
      }

      if(token.compare("$GPHDT")==0)
      {
        double heading_deg;
        iss >> car; iss >> heading_deg;
        //heading = heading_deg * PI / 180.0;
        cout << "heading : " << heading_deg << endl;
      }
    }
};
