#include "ros/ros.h"
#include <nav_msgs/Odometry.h>
#include <rosbag/bag.h>

rosbag::Bag bag;

void chatterCallback(const nav_msgs::Odometry& msg)
{	
	bag.write("gps_data", ros::Time::now(), msg);
}

int main(int argc, char **argv) {
	ros::init(argc, argv, "gps_listener");
	ros::NodeHandle n;
	
	bag.open("src/gps_novatel/bag/gps_data_fixe.bag", rosbag::bagmode::Write);

	ros::Subscriber sub = n.subscribe("gps_data", 1000, chatterCallback);

	ros::spin();
	
	bag.close();

	return 0;
}
