#include "ros/ros.h"
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/NavSatFix.h>

#include "gps_novatel.hpp"


int main(int argc, char **argv)
{
  int count=0;

  //GpsModule gps("/dev/ttyUSB0");
  GpsModule gps("/dev/novatelgps");
  gps.InitBestposa();

  ros::init(argc, argv, "novatel_driver");
  ros::NodeHandle n;

  ros::Publisher output_pub = n.advertise<nav_msgs::Odometry>("gps_data", 1000);
  ros::Publisher output_gps_pub = n.advertise<sensor_msgs::NavSatFix>("gps_data_raw", 1000);
  //ros::Rate loop_rate(10);

/*    if(!gps.IsOpen())
    {
      ROS_INFO("Gps closed");
    }
*/

  while (ros::ok())
  {
    nav_msgs::Odometry msg;
    sensor_msgs::NavSatFix gps_data;

    gps.ProcessData();
    

#define cov_x 1
#define cov_y 1
#define cov_z 1

//    msg.header.stamp = gps.universal_time;        // time of gps measurement
    msg.pose.pose.position.x = gps.position_x;    // x measurement GPS.
    msg.pose.pose.position.y = gps.position_y;    // y measurement GPS.
    msg.pose.pose.position.z = gps.position_z;    // z measurement GPS.
    msg.pose.pose.orientation.x = 0;              // identity quaternion
    msg.pose.pose.orientation.y = 0;              // identity quaternion
    msg.pose.pose.orientation.z = 1;              // identity quaternion
    msg.pose.pose.orientation.w = gps.heading;    // identity quaternion
    /*
    msg.pose.covariance = {cov_x, 0, 0, 0, 0, 0,  // covariance on gps_x
                            0, cov_y, 0, 0, 0, 0,  // covariance on gps_y
                            0, 0, cov_z, 0, 0, 0,  // covariance on gps_z
                            0, 0, 0, 99999, 0, 0,  // large covariance on rot x
                            0, 0, 0, 0, 99999, 0,  // large covariance on rot y
                            0, 0, 0, 0, 0, 99999};// large covariance on rot z
    */

    msg.twist.twist.linear.x = gps.velocity_x;
    msg.twist.twist.linear.y = gps.velocity_y;
    msg.twist.twist.linear.z = gps.velocity_z;
    
    gps_data.latitude  = gps.getLatitude();
    gps_data.longitude = gps.getLongitude();
    gps_data.altitude  = gps.getHauteur();

    //ROS_INFO("Get gps data: %i", count++);

    output_pub.publish(msg);
    output_gps_pub.publish(gps_data);

    ros::spinOnce();

    //loop_rate.sleep();
  }

  return 1;
}
