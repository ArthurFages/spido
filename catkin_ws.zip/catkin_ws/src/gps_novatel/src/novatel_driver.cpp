


NovatelDriver::init(std::string device)
{
  struct termios termios_cfg;

  gps_uart_ = open(device.c_str(), O_RDWR|O_NOCTTY);  //|O_NONBLOCK 
  if (gps_uart_< 0)
    cout << "error\n";

  tcgetattr(gps_uart_, &termios_cfg);


  termios_cfg.c_cflag = B115200| CS8 | CLOCAL | CREAD; // 8 bit + 1 stop 
  termios_cfg.c_iflag = IGNPAR | ICRNL;
  termios_cfg.c_oflag = 0;

  // positionne le mode de lecture (non canonique, sans echo, ...)
  termios_cfg.c_lflag = ICANON;

  //  Read non-bloquant avec delai
  termios_cfg.c_cc[VTIME]    = 100; // timer inter-caractères
  termios_cfg.c_cc[VMIN]     = 0;   // read bloquant jusqu'à ce que 0 lu


  tcflush(gps_uart_, TCIOFLUSH);
  tcsetattr(gps_uart_, TCSANOW,&termios_cfg);

  origine_flag = 1;
  heading = 0;
}
