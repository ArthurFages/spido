#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from __future__ import division

import rospy
import time
import rosbag
import std_msgs.msg
import numpy as np

from nav_msgs.msg import Odometry
from sensor_msgs.msg import NavSatFix
from sensor_msgs.msg import Imu
from geometry_msgs.msg import TwistStamped


# odometry results
odom_result = Odometry()

# offset pour recentrer les données GPS à la position actuelle
# [x_linear_offset, y_linear_offset, z_linear_offset, x_quaternion_offset, y_quaternion_offset, z_quaternion_offset, w_quaternion_offset]
offsets = [122, 122, 122, 122, 122, 122, 122]

# positionnement angulaire GPS
# [latitude, longitude, altitude]
ang_pos_GPS = [0,0,0]


earth_radius = 6370.0e3 # earth radius in meters
# fix point : Eiffel tower
# latitude = 48°51'30"
# longitude = 2°17'40"
x_origine = earth_radius*np.cos((48.+51./60+30./3600)*np.pi/180)*np.pi/180*(2.+17./60+40./3600)
y_origine = earth_radius*np.pi/180*(48.+51./60+30./3600)


def new_gps_data_raw(data) :

    global ang_pos_GPS
    global earth_radius
    global x_origine
    global y_origine

    ang_pos_GPS[0] = data.latitude
    ang_pos_GPS[1] = data.longitude
    ang_pos_GPS[2] = data.altitude

    latitude = float(data.latitude)*np.pi/180
    longitude = float(data.longitude)*np.pi/180

    odom_result.pose.pose.position.x = earth_radius*longitude*np.cos(latitude) - x_origine - offsets[0]
    odom_result.pose.pose.position.y = earth_radius*latitude - y_origine - offsets[1]
    odom_result.pose.pose.position.z = 0


def new_gps_data(data) :

    global odom_result
    global offsets

    odom_result.pose.pose.position.x = data.pose.pose.position.x - offsets[0]
    odom_result.pose.pose.position.y = data.pose.pose.position.y - offsets[1]
    odom_result.pose.pose.position.z = data.pose.pose.position.z - offsets[2]

def new_imu_data(data) :

    global odom_result
    global offsets

    odom_result.pose.pose.orientation.x = data.orientation.x - offsets[3]
    odom_result.pose.pose.orientation.y = data.orientation.y - offsets[4]
    odom_result.pose.pose.orientation.z = data.orientation.z - offsets[5]
    odom_result.pose.pose.orientation.w = data.orientation.w - offsets[6]

    
def new_velocity(data) :

    global odom_result

    odom_result.twist.twist.linear.x = data.twist.linear.x
    odom_result.twist.twist.linear.y = data.twist.linear.y
    odom_result.twist.twist.linear.z = data.twist.linear.z

    odom_result.twist.twist.angular.x = data.twist.angular.x
    odom_result.twist.twist.angular.y = data.twist.angular.y
    odom_result.twist.twist.angular.z = data.twist.angular.z

def set_offsets(x_lin,y_lin,z_lin,x_quat,y_quat,z_quat,w_quat) :

    global offsets

    offsets[0] = x_lin
    offsets[1] = y_lin
    offsets[2] = z_lin
    offsets[3] = x_quat
    offsets[4] = y_quat
    offsets[5] = z_quat
    offsets[6] = w_quat

def main() :

    global odom_result

    # bags for data visualisation
    odom_bag   = rosbag.Bag('odom.bag', 'w')

    rospy.init_node('spido_sensors_formatting')

    ## subscribers
    # gps
    rospy.Subscriber("gps_data_raw", NavSatFix, new_gps_data_raw)
    rospy.Subscriber("gps_data", Odometry, new_gps_data)
    # IMU
    rospy.Subscriber("imu/data", Imu, new_imu_data)
    rospy.Subscriber("velocity", TwistStamped, new_velocity)

    ## publishers
    odom_publisher  = rospy.Publisher('odom',Odometry,queue_size=10)

    r = rospy.Rate(10) 

    time.sleep(1)
    
    set_offsets(odom_result.pose.pose.position.x,
                odom_result.pose.pose.position.y,
                odom_result.pose.pose.position.z,
                odom_result.pose.pose.orientation.x,
                odom_result.pose.pose.orientation.y,
                odom_result.pose.pose.orientation.z,
                odom_result.pose.pose.orientation.w)

    while not rospy.is_shutdown() :

        ## formatage des données reçues
        
        odom_result.header = std_msgs.msg.Header()
        odom_result.header.stamp = rospy.Time.now() # Note you need to call rospy.init_node() before this will work
        odom_publisher.publish(odom_result)    

        try :
            odom_bag.write('odom', odom_result)
        except:
            print "[!] Erreur écriture data dans rosbag : odom"

    odom_bag.close()
    
if __name__ == '__main__':
    main()
    
    