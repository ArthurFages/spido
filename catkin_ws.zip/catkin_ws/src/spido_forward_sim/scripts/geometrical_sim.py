#!/usr/bin/env python2

import rospy
from std_msgs.msg import String
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from math import *
from spido_pure_interface.msg import cmd_car

delayBeforeExecuting = 0.5 #seconds
steering_radius = 3.0
center_to_wheel = 0.9
steering_direction = 1
speed_sign = 1
steering_angle = 0

def callback(data):
    rospy.loginfo(rospy.get_caller_id()+"I heard %s",data.steering_angle)
    global steering_radius
    global steering_direction
    global speed_sign
    global steering_angle
    steering_angle=data.steering_angle
    if data.linear_speed > 0:
        speed_sign = 1
    elif data.linear_speed < 0:
        speed_sign = -1
    if data.steering_angle > 0.05:
        steering_radius = center_to_wheel/sin(data.steering_angle)
        steering_direction = 1
        #rospy.loginfo("updated steering radius: %f",steering_radius)
    elif data.steering_angle < -0.05:
        steering_radius = center_to_wheel/sin(-data.steering_angle)
        steering_direction = -1
    else:
        steering_radius = 0.1


def talker():
    pathpub = rospy.Publisher('forward_sim_path_geometric', Path, queue_size=10)
    rospy.Subscriber("cmd_car", cmd_car, callback)
    rospy.init_node('geometric_path_forward_simulation', anonymous=True)
    r = rospy.Rate(10) # 10hz

    while not rospy.is_shutdown():
        #path init
        traj = Path()
        traj.header.frame_id = "base_link"
        traj.header.stamp = rospy.Time.now()
        steering_radius_buffered = steering_radius
        steering_direction_buffered = steering_direction
        steering_angle_buffered = steering_angle
        for i in range(0, 31):
            point = PoseStamped();
            point.header.frame_id = "base_link";
            #rospy.loginfo("computing with steering radius: %f",steering_radius_buffered)
            if abs(steering_angle_buffered) < 0.03:
                point.pose.position.x = speed_sign*i
                point.pose.position.y = 0
            else:
                point.pose.position.x = -steering_radius_buffered*cos(i/10.0+pi/2)*speed_sign
                point.pose.position.y = steering_radius_buffered*sin(i/10.0+pi/2) + steering_direction_buffered*steering_radius_buffered                
            point.header.stamp = rospy.Time(i);
            traj.poses.append(point)
        #Path trace and publish
        pathpub.publish(traj)
        r.sleep()
        #rospy.loginfo("publishing") #debug
    rospy.loginfo("out of the loop")

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException: pass
