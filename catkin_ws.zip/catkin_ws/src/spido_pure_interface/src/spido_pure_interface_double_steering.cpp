//---------------------------------spido_pure_interface------------------------------------
/* This node is a simple control interface for the fast-b robot from Robosoft.
 * The node subscribes to the "/cmd_car_safe" topic with a message of type "cmd_car"
 * This file is an update from spido_pure_interface.cpp with a double steering command msg
 * --------------------------
 * cmd_car message structure:
 * float32 linear_speed
 * float32 steering_angle_front
 * float32 steering_angle_rear
 * --------------------------
 * The callback function carCallback will transmit the target linear_speed and
 * steering_angle to the robot using the pure interface (interface.c)
 * -----------------------------------------------------------------------------
 * -----------------------------NEXT STEPS--------------------------------------
 * This is the only working feature for now, but there is a TODO list:
 * 
 * *Run some security tests
 * 
 * *Subscribe to another topic (cmd_drive for instance) to control the robot
 * giving two steering angles and each wheel speed.
 * 
 * *Same thing to control the two roll bars
 * 
 * *Publish diagnostic
 * 
 * *Publish each available data from the sensors
 * 
 * *Publish the laser data into a standard ROS laserscan message
 * 
 * *Anything else?
 * ----------------------------------END----------------------------------------
*/




#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "spido_pure_interface/cmd_car.h"


#include <sstream>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>

#include <unistd.h>
#include <stdint.h>
#include <pthread.h>
#include <signal.h>

//#include <cmath.h>
#include <math.h>

extern "C"{
#include "interface.h"                     //Pure communication library (C code)
}                  


void process_notification(int service, float timestamp, void *data)
{
  printf("Notification callback from %i\n", service);
}

void send_front_speed_command(float speed) {

  pure_drive_control_t front_speed;

  front_speed.enable = 1;
  front_speed.mode   = 1;
  front_speed.target = speed;

  pure_send_message_t message;
  message.notification.identifier = 0xFF;
  message.notification.target = 0x003;           // TO VERIFY : target 0x0200 - 0x4009 - 0x009 ?  pour drive service

  memcpy(message.notification.data, (void *)&front_speed, sizeof(front_speed));
  pure_send_message(message.buffer, sizeof(front_speed)+3);

}

void send_front_steering_command(float steering_angle) {

  pure_drive_control_t front_steering;

  front_steering.enable = 1;
  front_steering.mode   = 0;
  front_steering.target = steering_angle;

  pure_send_message_t message;
  message.notification.identifier = 0xFF;
  message.notification.target = 0x003;           // TO VERIFY : target 0x0200 - 0x4009 - 0x009 ?  pour drive service

  memcpy(message.notification.data, (void *)&front_steering, sizeof(front_steering));
  pure_send_message(message.buffer, sizeof(front_steering)+3);

}

void send_rear_steering_command(float steering_angle) {

  pure_drive_control_t rear_steering;

  rear_steering.enable = 1;
  rear_steering.mode   = 0;
  rear_steering.target = steering_angle;

  pure_send_message_t message;
  message.notification.identifier = 0xFF;
  message.notification.target = 0x003;           // TO VERIFY : target 0x0200 - 0x4009 - 0x009 ?  pour drive service

  memcpy(message.notification.data, (void *)&rear_steering, sizeof(rear_steering));
  pure_send_message(message.buffer, sizeof(rear_steering)+3);

}

void send_command(float front_speed, float front_steering, float rear_steering) {
  send_front_speed_command(front_speed);
  send_front_steering_command(front_steering);
  send_rear_steering_command(rear_steering);
}

void carCallback(const spido_pure_interface::cmd_car::ConstPtr& msg)
{
  //Test cmd line: # rostopic pub  /cmd_car spido_pure_interface/cmd_car -- 1 1
  ROS_INFO("Received cmd_car: linear_speed: %f | steering_angle_front %f | steering_angle_rear %f",
	   msg->linear_speed, msg->steering_angle_front, msg->steering_angle_rear);
  
  float front_steering  = msg->steering_angle_front;
  float rear_steering   = msg->steering_angle_rear;
  float front_speed     = msg->linear_speed;

  // control for excess
  if (front_speed > 0.5)
  {
      front_speed = 0.5;
  }
  if (std::fabs(front_steering) > 0.3)
  {
      front_steering = copysign(0.3, front_steering);
  }
  if (std::fabs(front_steering) < -0.3)
  {
      front_steering = copysign(-0.3, front_steering);
  }
  if (std::fabs(rear_steering) > 0.3)
  {
      rear_steering = copysign(0.3, rear_steering);
  }
  if (std::fabs(rear_steering) < -0.3)
  {
      rear_steering = copysign(-0.3, rear_steering);
  }

  send_command(front_speed, front_steering, rear_steering);

}

int main(int argc, char **argv)
{


  ros::init(argc, argv, "spido_pure_interface");
  ros::NodeHandle n;
  //TODO: subscibe and publish on the good topics with appropriate message type
  //ros::Publisher cmd_car_feedback = //TODO: remove or implement this
  //n.advertise<spido_pure_interface::cmd_car>("cmd_car_feedback", 1000);
  ros::Subscriber sub = n.subscribe("cmd_car_safe", 1000, carCallback);
  ros::Rate loop_rate(10); 		                //Loop rate for the main loop (Hz)
  


//--------------------------Pure communication init-----------------------------
  uint16_t diagnostic_instance = 0;
  pure_services_t *services;
  
  ROS_INFO("[*] Connexion settings");
  //printf("JE SAIS PAS OU J'ECRIS");
  pure_connection_start("192.168.1.2", 60000, process_notification);
  pure_directory_init();
  pure_directory_print();
  services = pure_directory_list();
  ROS_INFO("[OK] Connexion ");
  


//--------------------Search diagnostic service instance------------------------
  for(size_t i=0; i < services->number; i++)
    if(services->list[i].type == 0x0002)
    {
      diagnostic_instance = services->list[i].instance;
    }

  if(diagnostic_instance != 0) {
    pure_diagnostic_init(diagnostic_instance);
    pure_diagnostic_refresh();
    pure_diagnostic_print();
  };
 
  
//----------------------------Laser service-------------------------------------
/* ****************************** Laser broken ****************************** */
/*
  struct pure_laser_config_t laser_config;
  int len;
  pure_send_request(0x0006, pure_action_GET,
		    NULL, 0,(void *)&laser_config,&len);

  printf("\nLaser service data:\n");
  printf("x_pos= %.3f\n", laser_config.x_pos);
  printf("y_pos= %.3f\n", laser_config.y_pos);
  printf("heading= %.3f\n", laser_config.heading);
  printf("nb_echos= %i\n", laser_config.nb_echos);
*/
//-------------------------Laser service END------------------------------------



//-----------------------------Car service--------------------------------------
  /*struct pure_car_service_data_t car_config;
  int len;
  pure_send_request(0x0003, pure_action_GET,
		    NULL, 0,(void *)&car_config,&len);

  printf("\ncar service data:\n");
  printf("max_speed= %.3f\n", car_config.max_speed);
  printf("min_speed= %.3f\n", car_config.min_speed);
  printf("max_steering= %.3f\n", car_config.max_steering);
  printf("min_steering= %.3f\n", car_config.min_steering);
  printf("max_acceleration= %.3f\n", car_config.max_acceleration);
  printf("max_deceleration= %.3f\n", car_config.min_acceleration);
  printf("distance_between_axels= %f\n", car_config.wheelbase);*/
//--------------------------Car service END-------------------------------------


//-----------------------------Drive service--------------------------------------

  pure_drive_properties_t drive_config;
  int len;
  pure_send_request(0x0003, // target 0x0200 - 0x4009 - 0x009 ?  
        pure_action_GET,
        NULL, 0,(void *)&drive_config,&len);

  printf("\nDrive service data:\n");
  printf("position_max= %.3f\n", drive_config.position_max);
  printf("position_min= %.3f\n", drive_config.position_min);
  printf("velocity_max= %.3f\n", drive_config.velocity_max);
  printf("velocity_min= %.3f\n", drive_config.velocity_min);
  printf("acceleration_max= %.3f\n", drive_config.acceleration_max);
  printf("torque_max= %.3f\n", drive_config.torque_max);
  printf("torque_min= %f\n", drive_config.torque_min);

//----------------------------Drive service END-------------------------------------



  while (ros::ok())
  {
    ROS_INFO("pouet pouet");

//---------------------------------TEST Section---------------------------------
/*    

    // ================================== TEST FRONT STEERING =================
    printf("> front steering test");
    send_front_steering_command(0.1);
    sleep(1);

    // ================================== TEST REAR STEERING ==================
    printf("> rear steering test");
    send_rear_steering_command(0.1);
    sleep(1);
    
    // ================================== TEST FRONT STEERING =================
    printf("> front speed test");
    send_front_speed_command(0.1);
    sleep(0.5);

    // ================================== RAZ ==================================
    printf("> raz front speed test");
    send_front_speed_command(0);
    sleep(1);

    printf("> raz rear steering test");
    send_rear_steering_command(0);
    sleep(1);

    printf("> raz front steering test");
    send_front_steering_command(0);
    sleep(1);

*/
//-------------------------------END TEST Section-------------------------------

    ros::spinOnce();

    //loop_rate.sleep();
  }

  // RAZ FOR ALL DRIVE SERVICE BEFORE SHUT DOWN
  send_front_speed_command(0);
  send_front_steering_command(0);
  send_rear_steering_command(0);




  pure_connection_stop();
  printf("Connextion stopped\n");
  return 0;
}
