#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from __future__ import division

import rospy
import time
import rosbag
import std_msgs.msg

from nav_msgs.msg import Odometry

# recording path for rosbag
rosbag_record_path = "/home/spido/catkin_ws/rosbag/"

# odometry results
odom_result = Odometry()

def new_odom(data) :
     global odom_result
     odom_result = data

def main() :

    global odom_result
    global rosbag_record_path

    rospy.init_node('spido_path_recording')
    print "[*] Node created"

    # bags for data visualisation
    ref_path_bag   = rosbag.Bag(str(rosbag_record_path)+'ref_path.bag', 'w')
    print "[*] Bag correctly created"

    rospy.Subscriber("odom", Odometry, new_odom)

    r = rospy.Rate(10)
    
    try :
        while not rospy.is_shutdown() :
            ref_path_bag.write('odom', odom_result)
            r.sleep()
    except :
        print "[!] Erreur écriture data dans rosbag : ref_path"
    finally :
        ref_path_bag.close()
        print "[*] Bag closed"

if __name__ == '__main__':
    main()